import os
import time
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shutil
from visualization import create_policy_execution_gif

from env import GridWorldV6
from algos.lcb_vi import LCBVI
from algos.chi_square_dro import ChiSquareDRO
from algos.bernstein_vi_lcb import BernsteinVILCB
from algos.policy_generation import PolicyGenerator
import train


def run_metrics_v4():
    # Settings
    grid_size = 10
    wall_density = 0.1
    fatal_density = 0.05
    slip_prob = 0.2
    reward_noise = 0.1
    partial_obs = False
    seed = None
    uncertainty_param = 0.1
    n_train_episodes = 2000
    n_eval_episodes = 2000

    # Create output directory
    os.makedirs('datav4', exist_ok=True)

    # Initialize environment
    env = GridWorldV6(
        grid_size=grid_size,
        wall_density=wall_density,
        fatal_density=fatal_density,
        slip_prob=slip_prob,
        reward_noise=reward_noise,
        partial_observability=partial_obs,
        seed=seed
    )

    # Generate training trajectories (optimal only)
    print(f"Generating {n_train_episodes} expert trajectories for training...")
    trajectories = train.generate_trajectories(
        env,
        n_expert=n_train_episodes,
        n_suboptimal=0,
        n_random=0,
        n_curriculum=0,
        n_simplified=0,
        optimality_min=1.0,
        optimality_max=1.0,
        force_generate=True
    )
    traj_dict = {'expert': trajectories}

    # Compute optimal baseline return
    print("Evaluating optimal policy...")
    pg = PolicyGenerator(env)
    optimal_policy = pg.generate_optimal_policy_astar()
    opt_metrics = train.evaluate_policy(env, optimal_policy, n_episodes=n_eval_episodes)
    optimal_return = opt_metrics['avg_return']

    results = []
    algos = ['lcb_vi', 'dro', 'bernstein_vi_lcb']
    display_names = {'lcb_vi': 'LCB-VI', 'dro': 'DRO', 'bernstein_vi_lcb': 'Bernstein-VI-LCB'}

    for key in algos:
        name = display_names[key]
        print(f"\nTraining {name}...")
        t0 = time.time()
        policy = train.train_algorithm(key, env, traj_dict, uncertainty_param=uncertainty_param, save_dir='models')
        train_time = time.time() - t0

        print(f"Evaluating {name} for success rate and return...")
        m = train.evaluate_policy(env, policy, n_episodes=n_eval_episodes)
        success = m['success_rate']
        avg_return = m['avg_return']
        gap = optimal_return - avg_return

        results.append({
            'Algorithm': name,
            'Success Rate': success,
            'Training Time (s)': train_time,
            'Suboptimality Gap': gap
        })

        # Generate and save GIF for final policy
        os.makedirs('datav4/gifs', exist_ok=True)
        print(f"Generating GIF for {name}...")
        create_policy_execution_gif(env, policy, key, grid_size, uncertainty_param)
        src = f"datav3/gifs/{key}_grid{grid_size}_param{uncertainty_param}.gif"
        dst = f"datav4/gifs/{key}_grid{grid_size}_param{uncertainty_param}.gif"
        shutil.copy(src, dst)
        print(f"Saved GIF to {dst}")

    # Save metrics
    df = pd.DataFrame(results)
    metrics_path = 'datav4/metrics_v4.csv'
    df.to_csv(metrics_path, index=False)
    print(f"Saved metrics to {metrics_path}")

    # Plot bar chart
    df.set_index('Algorithm', inplace=True)
    ax = df.plot(kind='bar', figsize=(10, 6))
    ax.set_ylabel('Value')
    ax.set_title('Algorithm Comparison over 2000 Episodes')
    plt.tight_layout()
    plot_path = 'datav4/metrics_v4.png'
    plt.savefig(plot_path)
    plt.close()
    print(f"Saved bar chart to {plot_path}")


if __name__ == '__main__':
    run_metrics_v4()
