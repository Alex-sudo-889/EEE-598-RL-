import numpy as np
import heapq
from collections import defaultdict
import random

class PolicyGenerator:
    """
    Class for generating various types of policies for GridWorld environments:
    - Optimal policies using A* pathfinding
    - Sub-optimal policies with varying degrees of optimality
    - Random policies
    """
    
    def __init__(self, env):
        """
        Initialize the policy generator
        
        Args:
            env: GridWorld environment
        """
        self.env = env
        self.nrow = env.nrow
        self.ncol = env.ncol
        self.n_states = env.n_states
        self.n_actions = env.action_space.n
        self.grid = env.grid
        self.start_pos = env.start_pos
        self.goal_pos = env.goal_pos
    
    def generate_optimal_policy_astar(self):
        """
        Generate an optimal policy using A* pathfinding algorithm
        
        Returns:
            policy: Optimal policy as a numpy array of actions for each state
        """
        # Initialize policy with placeholder values
        policy = np.zeros(self.n_states, dtype=int)
        
        # Get goal position
        goal_row = self.goal_pos // self.ncol
        goal_col = self.goal_pos % self.ncol
        goal_pos = (goal_row, goal_col)
        
        # Cache paths to avoid redundant calculations
        path_cache = {}
        
        print(f"Generating optimal policy using A* for grid size {self.nrow}x{self.ncol}")
        
        # For each state, find the optimal path to the goal using A*
        for s in range(self.n_states):
            row, col = s // self.ncol, s % self.ncol
            current_pos = (row, col)
            
            # Skip walls, fatal squares, and the goal itself
            if self.grid[row, col] in [1, 4, 3]:
                continue
            
            # Check if we already computed a path from this position
            if current_pos in path_cache:
                path = path_cache[current_pos]
            else:
                # Find the optimal path from this state to the goal
                path = self._astar_search(current_pos, goal_pos)
                # Cache the result
                path_cache[current_pos] = path
            
            if path and len(path) > 1:
                # Get the next position in the path
                next_pos = path[1]
                next_row, next_col = next_pos
                
                # Determine action (0: LEFT, 1: DOWN, 2: RIGHT, 3: UP)
                if next_col < col:
                    policy[s] = 0  # LEFT
                elif next_row > row:
                    policy[s] = 1  # DOWN
                elif next_col > col:
                    policy[s] = 2  # RIGHT
                elif next_row < row:
                    policy[s] = 3  # UP
            else:
                # If no path found, use a simple heuristic
                if col < goal_col:
                    policy[s] = 2  # RIGHT
                elif row < goal_row:
                    policy[s] = 1  # DOWN
                elif col > goal_col:
                    policy[s] = 0  # LEFT
                elif row > goal_row:
                    policy[s] = 3  # UP
                else:
                    # Random action as fallback
                    policy[s] = np.random.randint(0, 4)
        
        # Verify policy quality
        policy_quality = self._evaluate_policy_quality(policy)
        print(f"A* policy generation complete. Policy quality: {policy_quality:.2f}")
        
        return policy
        
    def _evaluate_policy_quality(self, policy, n_samples=10):
        """
        Evaluate the quality of a policy by simulating trajectories
        
        Args:
            policy: Policy to evaluate
            n_samples: Number of sample trajectories to generate
            
        Returns:
            quality: Average success rate (0.0 to 1.0)
        """
        successes = 0
        
        for _ in range(n_samples):
            trajectory = self.env.generate_trajectory(policy, max_steps=self.nrow * self.ncol * 2)
            if trajectory['success']:
                successes += 1
        
        return successes / n_samples
    
    def _astar_search(self, start, goal):
        """
        A* search algorithm to find the optimal path from start to goal
        
        Args:
            start: Tuple of (row, col) for the start position
            goal: Tuple of (row, col) for the goal position
            
        Returns:
            path: List of positions from start to goal
        """
        # Define heuristic function (Manhattan distance)
        def heuristic(pos):
            return abs(pos[0] - goal[0]) + abs(pos[1] - goal[1])
        
        # Define neighbors function with action costs
        def get_neighbors(pos):
            row, col = pos
            neighbors = []
            
            # Check all four directions
            # Direction order: LEFT, DOWN, RIGHT, UP
            directions = [
                (0, -1, 0),  # LEFT
                (1, 0, 1),   # DOWN
                (0, 1, 2),   # RIGHT
                (-1, 0, 3)   # UP
            ]
            
            # Prioritize moving toward the goal when possible
            if goal[0] > row:  # Goal is below
                directions = [directions[1]] + [d for i, d in enumerate(directions) if i != 1]
            elif goal[0] < row:  # Goal is above
                directions = [directions[3]] + [d for i, d in enumerate(directions) if i != 3]
            elif goal[1] > col:  # Goal is to the right
                directions = [directions[2]] + [d for i, d in enumerate(directions) if i != 2]
            elif goal[1] < col:  # Goal is to the left
                directions = [directions[0]] + [d for i, d in enumerate(directions) if i != 0]
            
            for dr, dc, action in directions:
                new_row, new_col = row + dr, col + dc
                
                # Check if the new position is valid
                if (0 <= new_row < self.nrow and 0 <= new_col < self.ncol and 
                    self.grid[new_row, new_col] not in [1, 4]):  # Not a wall or fatal square
                    # Cost is 1 for normal movement
                    cost = 1
                    
                    # Add neighbor with its action and cost
                    neighbors.append(((new_row, new_col), action, cost))
            
            return neighbors
        
        # Initialize data structures for A*
        open_set = []  # Priority queue
        g_scores = {start: 0}  # Cost from start to current position
        f_scores = {start: heuristic(start)}  # Estimated cost from start to goal through current position
        came_from = {}  # Parent pointers to reconstruct path
        actions = {}  # Actions taken to reach each position
        
        # Add start position to open set
        heapq.heappush(open_set, (f_scores[start], 0, start))  # (f_score, tiebreaker, position)
        
        # Counter for tiebreaking equal f-scores
        counter = 1
        
        while open_set:
            # Get position with lowest f_score
            _, _, current = heapq.heappop(open_set)
            
            # Check if we reached the goal
            if current == goal:
                # Reconstruct path
                path = [current]
                action_path = []
                
                while current in came_from:
                    current = came_from[current]
                    path.append(current)
                    if current in actions:
                        action_path.append(actions[current])
                
                # Reverse to get path from start to goal
                path.reverse()
                action_path.reverse()
                
                return path
            
            # Explore neighbors
            for neighbor_pos, action, cost in get_neighbors(current):
                # Calculate tentative g_score
                tentative_g = g_scores[current] + cost
                
                # If we found a better path to this neighbor
                if neighbor_pos not in g_scores or tentative_g < g_scores[neighbor_pos]:
                    # Update path information
                    came_from[neighbor_pos] = current
                    actions[neighbor_pos] = action
                    g_scores[neighbor_pos] = tentative_g
                    f_scores[neighbor_pos] = tentative_g + heuristic(neighbor_pos)
                    
                    # Add to open set if not already there
                    if not any(pos == neighbor_pos for _, _, pos in open_set):
                        heapq.heappush(open_set, (f_scores[neighbor_pos], counter, neighbor_pos))
                        counter += 1
        
        # No path found
        return None
    
    def generate_suboptimal_policy(self, optimality=0.7):
        """
        Generate a sub-optimal policy by mixing optimal and random actions
        
        Args:
            optimality: Probability of taking the optimal action (0.0 to 1.0)
            
        Returns:
            policy: Sub-optimal policy as a numpy array of actions for each state
        """
        # Get the optimal policy
        optimal_policy = self.generate_optimal_policy_astar()
        
        # Initialize sub-optimal policy
        suboptimal_policy = np.copy(optimal_policy)
        
        # For each state, randomly replace optimal action with a random action
        for s in range(self.n_states):
            row, col = s // self.ncol, s % self.ncol
            
            # Skip walls, fatal squares, and the goal
            if self.grid[row, col] in [1, 4, 3]:
                continue
            
            # With probability (1 - optimality), choose a random action
            if np.random.random() > optimality:
                # Choose a random action different from the optimal one
                possible_actions = [a for a in range(self.n_actions) if a != optimal_policy[s]]
                if possible_actions:
                    suboptimal_policy[s] = np.random.choice(possible_actions)
        
        return suboptimal_policy
    
    def generate_epsilon_greedy_policy(self, epsilon=0.2):
        """
        Generate an epsilon-greedy policy based on the optimal policy
        
        Args:
            epsilon: Probability of taking a random action (0.0 to 1.0)
            
        Returns:
            policy: Epsilon-greedy policy as a numpy array of actions for each state
        """
        # Get the optimal policy
        optimal_policy = self.generate_optimal_policy_astar()
        
        # Initialize epsilon-greedy policy
        epsilon_greedy_policy = np.copy(optimal_policy)
        
        # For each state, with probability epsilon, choose a random action
        for s in range(self.n_states):
            row, col = s // self.ncol, s % self.ncol
            
            # Skip walls, fatal squares, and the goal
            if self.grid[row, col] in [1, 4, 3]:
                continue
            
            # With probability epsilon, choose a random action
            if np.random.random() < epsilon:
                epsilon_greedy_policy[s] = np.random.randint(0, self.n_actions)
        
        return epsilon_greedy_policy
    
    def generate_random_policy(self):
        """
        Generate a completely random policy
        
        Returns:
            policy: Random policy as a numpy array of actions for each state
        """
        return np.random.randint(0, self.n_actions, size=self.n_states)
    
    def generate_biased_random_policy(self, bias_action=None):
        """
        Generate a random policy biased towards a specific action
        
        Args:
            bias_action: Action to bias towards (0: LEFT, 1: DOWN, 2: RIGHT, 3: UP)
                        If None, a random action will be chosen as the bias
                        
        Returns:
            policy: Biased random policy as a numpy array of actions for each state
        """
        # If no bias action is provided, choose a random one
        if bias_action is None:
            bias_action = np.random.randint(0, self.n_actions)
        
        # Initialize policy
        policy = np.zeros(self.n_states, dtype=int)
        
        # For each state, choose the bias action with 70% probability
        for s in range(self.n_states):
            if np.random.random() < 0.7:
                policy[s] = bias_action
            else:
                # Choose a random action different from the bias
                possible_actions = [a for a in range(self.n_actions) if a != bias_action]
                policy[s] = np.random.choice(possible_actions)
        
        return policy
    
    def generate_curriculum_trajectories(self, n_trajectories=50, difficulty_levels=3):
        """
        Generate trajectories using curriculum learning (gradually increasing difficulty)
        
        Args:
            n_trajectories: Number of trajectories per difficulty level
            difficulty_levels: Number of difficulty levels
            
        Returns:
            trajectories: List of trajectories with curriculum metadata
        """
        trajectories = []
        
        # Save original environment parameters
        original_slip_prob = self.env.slip_prob
        original_reward_noise = self.env.reward_noise
        
        for level in range(difficulty_levels):
            # Calculate difficulty parameters (gradually increasing)
            slip_prob = original_slip_prob * (level + 1) / difficulty_levels
            reward_noise = original_reward_noise * (level + 1) / difficulty_levels
            
            # Temporarily modify environment
            self.env.slip_prob = slip_prob
            self.env.reward_noise = reward_noise
            
            # Generate optimal policy for this difficulty level
            optimal_policy = self.generate_optimal_policy_astar()
            
            # Generate trajectories
            for _ in range(n_trajectories):
                trajectory = self.env.generate_trajectory(optimal_policy)
                if trajectory['success']:
                    trajectory['is_expert'] = True
                    trajectory['policy_type'] = 'curriculum'
                    trajectory['difficulty_level'] = level + 1
                    trajectory['slip_prob'] = slip_prob
                    trajectory['reward_noise'] = reward_noise
                    trajectories.append(trajectory)
        
        # Restore original environment parameters
        self.env.slip_prob = original_slip_prob
        self.env.reward_noise = original_reward_noise
        
        return trajectories
    
    def generate_simplified_demonstrations(self, n_trajectories=50):
        """
        Generate demonstrations from simplified environment (reduced stochasticity)
        
        Args:
            n_trajectories: Number of trajectories
            
        Returns:
            trajectories: List of trajectories from simplified environment
        """
        trajectories = []
        
        # Save original environment parameters
        original_slip_prob = self.env.slip_prob
        original_reward_noise = self.env.reward_noise
        
        # Set simplified parameters (reduced stochasticity)
        self.env.slip_prob = 0.05  # Very low slip probability
        self.env.reward_noise = 0.01  # Very low reward noise
        
        # Generate optimal policy for simplified environment
        optimal_policy = self.generate_optimal_policy_astar()
        
        # Generate trajectories
        for _ in range(n_trajectories):
            trajectory = self.env.generate_trajectory(optimal_policy)
            if trajectory['success']:
                trajectory['is_expert'] = True
                trajectory['policy_type'] = 'simplified'
                trajectory['slip_prob'] = self.env.slip_prob
                trajectory['reward_noise'] = self.env.reward_noise
                trajectories.append(trajectory)
        
        # Restore original environment parameters
        self.env.slip_prob = original_slip_prob
        self.env.reward_noise = original_reward_noise
        
        return trajectories
    
    def generate_mixed_dataset(self, n_optimal=100, n_suboptimal=100, n_random=100, n_curriculum=50, n_simplified=50, optimality_range=(0.5, 0.9)):
        """
        Generate a mixed dataset of trajectories from different policy types
        
        Args:
            n_optimal: Number of optimal trajectories
            n_suboptimal: Number of sub-optimal trajectories
            n_random: Number of random trajectories
            n_curriculum: Number of curriculum learning trajectories
            n_simplified: Number of simplified environment trajectories
            optimality_range: Range of optimality for sub-optimal policies
            
        Returns:
            trajectories: List of trajectories
        """
        trajectories = []
        
        # Generate optimal trajectories using A*
        optimal_policy = self.generate_optimal_policy_astar()
        for _ in range(n_optimal):
            trajectory = self.env.generate_trajectory(optimal_policy)
            if trajectory['success']:
                trajectory['is_expert'] = True
                trajectory['policy_type'] = 'optimal'
                trajectories.append(trajectory)
        
        # Generate sub-optimal trajectories with varying degrees of optimality
        for _ in range(n_suboptimal):
            optimality = np.random.uniform(*optimality_range)
            suboptimal_policy = self.generate_suboptimal_policy(optimality)
            trajectory = self.env.generate_trajectory(suboptimal_policy)
            trajectory['is_expert'] = False
            trajectory['policy_type'] = 'suboptimal'
            trajectory['optimality'] = optimality
            trajectories.append(trajectory)
        
        # Generate random trajectories (mix of pure random and biased random)
        for _ in range(n_random):
            if np.random.random() < 0.7:  # 70% pure random
                random_policy = self.generate_random_policy()
                policy_type = 'random'
            else:  # 30% biased random
                random_policy = self.generate_biased_random_policy()
                policy_type = 'biased_random'
                
            trajectory = self.env.generate_trajectory(random_policy)
            trajectory['is_expert'] = False
            trajectory['policy_type'] = policy_type
            trajectories.append(trajectory)
        
        # Generate curriculum learning trajectories
        curriculum_trajectories = self.generate_curriculum_trajectories(n_trajectories=n_curriculum // 3, difficulty_levels=3)
        trajectories.extend(curriculum_trajectories)
        
        # Generate simplified environment demonstrations
        simplified_trajectories = self.generate_simplified_demonstrations(n_trajectories=n_simplified)
        trajectories.extend(simplified_trajectories)
        
        # Generate epsilon-greedy trajectories
        epsilon_greedy_policy = self.generate_epsilon_greedy_policy(epsilon=0.2)
        for _ in range(n_curriculum // 3):  # Use 1/3 of curriculum budget for epsilon-greedy
            trajectory = self.env.generate_trajectory(epsilon_greedy_policy)
            trajectory['is_expert'] = False
            trajectory['policy_type'] = 'epsilon_greedy'
            trajectory['epsilon'] = 0.2
            trajectories.append(trajectory)
        
        print(f"Generated {len(trajectories)} total trajectories:")
        policy_types = {}
        for traj in trajectories:
            policy_type = traj['policy_type']
            policy_types[policy_type] = policy_types.get(policy_type, 0) + 1
        
        for policy_type, count in policy_types.items():
            print(f"  - {policy_type}: {count}")
        
        return trajectories
