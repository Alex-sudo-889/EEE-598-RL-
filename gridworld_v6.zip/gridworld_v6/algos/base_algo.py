import numpy as np

class BaseAlgorithm:
    """Base class for all algorithms"""
    
    def __init__(self, n_states, n_actions, gamma=0.99):
        """
        Initialize the base algorithm
        
        Args:
            n_states: Number of states in the environment
            n_actions: Number of actions in the environment
            gamma: Discount factor
        """
        self.n_states = n_states
        self.n_actions = n_actions
        self.gamma = gamma
        
        # Initialize policy and value function
        self.policy = np.zeros(n_states, dtype=int)
        self.values = np.zeros(n_states)
    
    def train(self, trajectories):
        """
        Train the algorithm on trajectories
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            policy: The learned policy
        """
        raise NotImplementedError("Subclasses must implement train()")
    
    def save(self, filepath):
        """
        Save the algorithm to a file
        
        Args:
            filepath: Path to save the algorithm
        """
        np.savez(filepath, 
                 policy=self.policy, 
                 values=self.values,
                 n_states=self.n_states,
                 n_actions=self.n_actions,
                 gamma=self.gamma)
        print(f"Algorithm saved to {filepath}")
    
    def load(self, filepath):
        """
        Load the algorithm from a file
        
        Args:
            filepath: Path to load the algorithm from
        """
        data = np.load(filepath)
        self.policy = data['policy']
        self.values = data['values']
        self.n_states = data['n_states']
        self.n_actions = data['n_actions']
        self.gamma = data['gamma']
        print(f"Algorithm loaded from {filepath}")
        
        return self.policy
