import numpy as np
from .base_algo import BaseAlgorithm
import random  # for data splitting
import math

class LCBVI(BaseAlgorithm):
    """Lower Confidence Bound Value Iteration algorithm
    
    Implementation of Algorithm 3: Offline value iteration with LCB from
    "Bridging Offline Reinforcement Learning and Imitation Learning: A Tale of Pessimism"
    by Jin et al., 2020.
    """
    
    def __init__(self, n_states, n_actions, delta=0.05, gamma=0.99, epsilon=1e-6, max_iterations=None, v_max=1.0):
        """
        Initialize the LCB-VI algorithm
        
        Args:
            n_states: Number of states in the environment
            n_actions: Number of actions in the environment
            delta: Confidence parameter (1-delta is the confidence level)
            gamma: Discount factor
            epsilon: Convergence threshold
            max_iterations: Maximum number of iterations (if None, will be set based on sample count)
            v_max: Maximum value function (used for scaling the penalty)
        """
        super().__init__(n_states, n_actions, gamma)
        self.delta = delta
        self.epsilon = epsilon
        self.max_iterations = max_iterations
        self.v_max = v_max  # Maximum value function (usually 1/(1-gamma) for [0,1] rewards)
        
        # Initialize value function and policy
        self.values = np.zeros(self.n_states)
        self.Q = np.zeros((self.n_states, self.n_actions))
        
        # Data structures for T+1 splits
        self.data_splits = []  # Will hold T+1 data splits
        self.T = None  # Number of iterations (computed from data)
    
    def split_data(self, trajectories):
        """
        Split the data into T+1 equal parts as required by Algorithm 3
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            T: Number of iterations to run
        """
        # Calculate total number of samples
        total_samples = 0
        for trajectory in trajectories:
            total_samples += len(trajectory['actions'])
        
        # Calculate T based on the paper: T = ceil(ln(N)/(1-gamma))
        self.T = math.ceil(math.log(total_samples) / (1 - self.gamma))
        print(f"Using T = {self.T} iterations based on {total_samples} total samples")
        
        # Set max_iterations if not provided
        if self.max_iterations is None:
            self.max_iterations = self.T
        
        # Create T+1 splits
        self.data_splits = []
        random.shuffle(trajectories)  # Shuffle to ensure randomness
        
        # Create indices for splitting
        indices = np.linspace(0, len(trajectories), self.T + 2, dtype=int)
        
        # Split the data into T+1 parts
        for t in range(self.T + 1):
            start_idx = indices[t]
            end_idx = indices[t + 1]
            self.data_splits.append(trajectories[start_idx:end_idx])
        
        print(f"Data split into {self.T + 1} parts")
        return self.T
    
    def build_empirical_model(self, trajectories, t=0):
        """
        Build empirical transition and reward models from trajectories
        for iteration t
        
        Args:
            trajectories: List of trajectories
            t: Iteration number (which data split to use)
        """
        print(f"Building empirical model from data split {t}...")
        
        # Initialize counters
        transition_counts = np.zeros((self.n_states, self.n_actions, self.n_states))
        reward_sums = np.zeros((self.n_states, self.n_actions))
        visit_counts = np.zeros((self.n_states, self.n_actions))
        
        # Process trajectories
        for trajectory in trajectories:
            states = trajectory['states']
            actions = trajectory['actions']
            rewards = trajectory['rewards']
            next_states = trajectory['next_states']
            
            for i in range(len(actions)):
                s = states[i]
                a = actions[i]
                r = rewards[i]
                s_next = next_states[i]
                
                # Update counts
                transition_counts[s, a, s_next] += 1
                reward_sums[s, a] += r
                visit_counts[s, a] += 1
        
        return transition_counts, reward_sums, visit_counts
    
    def compute_penalty(self, m_t_sa, t):
        """
        Compute the penalty term as per Equation 19 in the paper
        
        Args:
            m_t_sa: Visit count for state-action pair at iteration t
            t: Iteration number
            
        Returns:
            penalty: The penalty term b_t(s,a)
        """
        # L = 2000 * ln(2(T+1)SA/delta)
        L = 2000 * np.log(2 * (self.T + 1) * self.n_states * self.n_actions / self.delta)
        
        # b_t(s,a) = V_max * sqrt(L / max(m_t(s,a), 1))
        denominator = max(m_t_sa, 1)  # Ensure non-zero denominator
        penalty = self.v_max * np.sqrt(L / denominator)
        
        return penalty
    
    def get_transition_probs(self, transition_counts_t, s, a):
        """
        Get empirical transition probabilities from counts
        
        Args:
            transition_counts_t: Transition counts for iteration t
            s: State
            a: Action
            
        Returns:
            probs: Empirical transition probabilities P_t(·|s,a)
        """
        counts = transition_counts_t[s, a]
        total = np.sum(counts)
        
        if total == 0:
            # If no data, use uniform distribution
            return np.ones(self.n_states) / self.n_states
        
        # Return empirical distribution
        return counts / total
    
    def get_expected_reward(self, reward_sums_t, visit_counts_t, s, a):
        """
        Get empirical expected reward
        
        Args:
            reward_sums_t: Reward sums for iteration t
            visit_counts_t: Visit counts for iteration t
            s: State
            a: Action
            
        Returns:
            reward: Empirical expected reward r_t(s,a)
        """
        if visit_counts_t[s, a] == 0:
            return 0.0
        return reward_sums_t[s, a] / visit_counts_t[s, a]
    
    def lcb_value_iteration(self):
        """
        Run LCB Value Iteration as per Algorithm 3 in the paper
        "Bridging Offline Reinforcement Learning and Imitation Learning"
        
        Returns:
            policy: The learned policy
        """
        print("Running Value Iteration with LCB as per Algorithm 3...")
        
        # Initialize value function, Q-values, and policy
        V = np.zeros(self.n_states)  # V^0
        Q = np.zeros((self.n_states, self.n_actions))  # Q^0
        policy = np.zeros(self.n_states, dtype=int)  # π^0
        
        # Build initial model from D_0
        transition_counts_0, reward_sums_0, visit_counts_0 = self.build_empirical_model(self.data_splits[0], 0)
        
        # Initialize policy based on visit counts (Line 3 in Algorithm 3)
        for s in range(self.n_states):
            if np.sum(visit_counts_0[s]) > 0:
                policy[s] = np.argmax(visit_counts_0[s])
        
        # Value iteration loop (Line 4 in Algorithm 3)
        for t in range(1, min(self.T + 1, self.max_iterations + 1)):
            print(f"\nIteration {t}/{self.T}")
            
            # Store previous values and policy
            V_prev = V.copy()
            policy_prev = policy.copy()
            
            # Build empirical model from D_t
            transition_counts_t, reward_sums_t, visit_counts_t = self.build_empirical_model(self.data_splits[t], t)
            
            # Compute V_t^mid and π_t^mid (Lines 5-14 in Algorithm 3)
            V_mid = np.zeros(self.n_states)
            policy_mid = np.zeros(self.n_states, dtype=int)
            
            # Update Q-values for each state-action pair
            for s in range(self.n_states):
                for a in range(self.n_actions):
                    # Get empirical transition probabilities
                    probs = self.get_transition_probs(transition_counts_t, s, a)
                    
                    # Get empirical expected reward
                    r = self.get_expected_reward(reward_sums_t, visit_counts_t, s, a)
                    
                    # Compute penalty term
                    penalty = self.compute_penalty(visit_counts_t[s, a], t)
                    
                    # Update Q-value with penalty (Line 11 in Algorithm 3)
                    Q[s, a] = r + self.gamma * np.sum(probs * V_prev) - penalty
                
                # Compute V_t^mid and π_t^mid
                if np.any(visit_counts_t[s] > 0):  # Only update if we have data
                    V_mid[s] = np.max(Q[s])
                    policy_mid[s] = np.argmax(Q[s])
            
            # Apply monotonic update rule (Lines 15-17 in Algorithm 3)
            for s in range(self.n_states):
                if V_mid[s] > V_prev[s]:
                    V[s] = V_mid[s]
                    policy[s] = policy_mid[s]
                else:
                    V[s] = V_prev[s]
                    policy[s] = policy_prev[s]
            
            # Check for convergence
            delta = np.max(np.abs(V - V_prev))
            print(f"  Delta = {delta:.6f}")
            
            if delta < self.epsilon:
                print(f"Converged after {t} iterations.")
                break
        
        # Store final values and policy
        self.values = V.copy()
        self.Q = Q.copy()
        self.policy = policy.copy()
        
        print("LCB-VI complete.")
        return self.policy
    
    def train(self, trajectories):
        """
        Train the algorithm on trajectories
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            policy: The learned policy
        """
        # Split data into T+1 parts
        self.split_data(trajectories)
        
        # Run LCB-VI algorithm
        self.lcb_value_iteration()
        
        return self.policy
    
    def save(self, filepath):
        """
        Save the algorithm to a file
        
        Args:
            filepath: Path to save the algorithm
        """
        np.savez(filepath, 
                 policy=self.policy,
                 values=self.values if hasattr(self, 'values') else np.zeros(self.n_states),
                 Q=self.Q if hasattr(self, 'Q') else np.zeros((self.n_states, self.n_actions)),
                 n_states=self.n_states,
                 n_actions=self.n_actions,
                 gamma=self.gamma,
                 delta=self.delta,
                 v_max=self.v_max,
                 T=self.T if hasattr(self, 'T') else 0)
        print(f"LCB-VI algorithm saved to {filepath}")
    
    def load(self, filepath):
        """
        Load the algorithm from a file
        
        Args:
            filepath: Path to load the algorithm from
            
        Returns:
            policy: The loaded policy
        """
        data = np.load(filepath, allow_pickle=True)
        
        # Load policy, values, and Q-values
        self.policy = data['policy']
        if 'values' in data:
            self.values = data['values']
        if 'Q' in data:
            self.Q = data['Q']
        
        # Load algorithm parameters
        self.n_states = data['n_states']
        self.n_actions = data['n_actions']
        self.gamma = data['gamma']
        self.delta = data['delta'] if 'delta' in data else 0.05
        self.v_max = data['v_max'] if 'v_max' in data else 1.0
        self.T = data['T'] if 'T' in data else 0
        
        print(f"LCB-VI algorithm loaded from {filepath}")
        
        return self.policy
