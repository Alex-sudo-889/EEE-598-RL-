import os
import numpy as np
# Set the matplotlib backend to Agg (non-interactive) for headless environments
import matplotlib
matplotlib.use('Agg')  # Must be before importing pyplot
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.colors as mcolors
import pandas as pd
import pickle
import seaborn as sns
import imageio
import time
from tqdm import tqdm
import glob
import shutil
from train import generate_trajectories, train_algorithm

from env import GridWorldV6
from algos.lcb_vi import LCBVI
from algos.chi_square_dro import ChiSquareDRO
from algos.bernstein_vi_lcb import BernsteinVILCB

# Create output directories
os.makedirs("data/visualizations/gifs", exist_ok=True)
os.makedirs("data/visualizations/plots", exist_ok=True)
os.makedirs("data/visualizations/metrics", exist_ok=True)
os.makedirs("data/gifs", exist_ok=True)
os.makedirs("data/plots", exist_ok=True)
os.makedirs("data/metrics", exist_ok=True)
os.makedirs("data/advanced_metrics", exist_ok=True)
os.makedirs("data/advanced_metrics/logs", exist_ok=True)
os.makedirs("data", exist_ok=True)
os.makedirs("data/logs", exist_ok=True)

# Set plot style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (12, 8)
plt.rcParams['font.size'] = 12

# Define algorithm colors for consistent visualization
ALGO_COLORS = {
    'lcb_vi': '#1f77b4',  # Blue
    'dro': '#ff7f0e',  # Orange for DRO
    'chi_square_dro': '#ff7f0e',  # Alias for DRO
    'bernstein_vi_lcb': '#2ca02c',  # Green
    'optimal': '#d62728'  # Red
}

# Define algorithm display names
ALGO_NAMES = {
    'lcb_vi': 'LCB-VI',
    'dro': 'DRO',
    'chi_square_dro': 'DRO',
    'bernstein_vi_lcb': 'Bernstein-VI-LCB',
    'optimal': 'Optimal Policy'
}

# Map display names to their colors
DISPLAY_COLORS = {ALGO_NAMES[k]: v for k, v in ALGO_COLORS.items()}

def create_policy_execution_gif(env, policy, algo_name, grid_size, uncertainty_param, max_steps=100, fps=5, save_gif=True):
    # Create a temporary directory for frames
    import tempfile
    import os
    temp_dir = tempfile.mkdtemp()
    """
    Create a GIF of policy execution in the environment
    
    Args:
        env: GridWorld environment
        policy: Policy to execute
        algo_name: Name of the algorithm
        grid_size: Size of the grid
        uncertainty_param: Uncertainty parameter used
        max_steps: Maximum number of steps to execute
        fps: Frames per second for the GIF
        save_gif: Whether to save the GIF or just return the results
    
    Returns:
        gif_path: Path to the saved GIF (if saved)
        total_reward: Total reward received
        step: Number of steps taken
        success: Whether the episode was successful
    """
    if save_gif:
        print(f"Creating policy execution GIF for {algo_name}...")
    
    # Reset environment
    state, _ = env.reset()
    
    # Create a colormap for visualization
    colors = ['white', 'black', 'green', 'blue', 'red', 'yellow']
    cmap = mcolors.ListedColormap(colors)
    
    # Store frames
    frames = []
    
    # Execute policy
    done = False
    step = 0
    total_reward = 0
    success = False
    
    while not done and step < max_steps:
        if save_gif:
            # Create a grid for visualization
            vis_grid = env.grid.copy()
            
            # Mark the current position
            current_row = state // env.ncol
            current_col = state % env.ncol
            if vis_grid[current_row, current_col] == 0:  # Only mark if it's an empty cell
                vis_grid[current_row, current_col] = 5  # Yellow for current position
            
            # Create a figure and axis
            fig, ax = plt.subplots(figsize=(8, 8))
            
            # Plot the grid
            ax.imshow(vis_grid, cmap=cmap, vmin=0, vmax=5)
            
            # Add grid lines
            ax.grid(which='major', axis='both', linestyle='-', color='k', linewidth=2)
            ax.set_xticks(np.arange(-0.5, env.ncol, 1))
            ax.set_yticks(np.arange(-0.5, env.nrow, 1))
            
            # Remove tick labels
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            
            # Add title and step information
            plt.title(f"{ALGO_NAMES[algo_name]} Policy Execution\nStep: {step}, Reward: {total_reward:.2f}")
            
            # Save frame to file
            frame_path = os.path.join(temp_dir, f'frame_{step:03d}.png')
            fig.savefig(frame_path)
            frames.append(frame_path)
            plt.close(fig)
        
        # Take action according to policy
        action = policy[state]
        next_state, reward, done, _, _ = env.step(action)
        
        # Update state and reward
        state = next_state
        total_reward += reward
        step += 1
    
    # Check if the episode was successful (reached the goal)
    success = done and env.grid[state // env.ncol, state % env.ncol] == 3
    
    if save_gif:
        # Add final frame showing success or failure
        vis_grid = env.grid.copy()
        current_row = state // env.ncol
        current_col = state % env.ncol
        if vis_grid[current_row, current_col] == 0:
            vis_grid[current_row, current_col] = 5
        
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.imshow(vis_grid, cmap=cmap, vmin=0, vmax=5)
        ax.grid(which='major', axis='both', linestyle='-', color='k', linewidth=2)
        ax.set_xticks(np.arange(-0.5, env.ncol, 1))
        ax.set_yticks(np.arange(-0.5, env.nrow, 1))
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        
        if success:
            plt.title(f"{ALGO_NAMES[algo_name]} Policy Execution\nSuccess! Total Reward: {total_reward:.2f}")
        else:
            plt.title(f"{ALGO_NAMES[algo_name]} Policy Execution\nFailed! Total Reward: {total_reward:.2f}")
        
        fig.canvas.draw()
        # Save final frame to file
        frame_path = os.path.join(temp_dir, f'frame_final.png')
        fig.savefig(frame_path)
        frames.append(frame_path)
        plt.close(fig)
        
        # Save GIF
        gif_path = f"data/visualizations/gifs/{algo_name}_grid{grid_size}_param{uncertainty_param}.gif"
        gif_v3 = f"data/gifs/{algo_name}_grid{grid_size}_param{uncertainty_param}.gif"
        # Read the frames as images and create the GIF
        images = [imageio.imread(frame) for frame in frames]
        imageio.mimsave(gif_path, images, fps=fps)
        imageio.mimsave(gif_v3, images, fps=fps)
        print(f"GIF saved to {gif_path}")
        print(f"GIF also saved to {gif_v3}")
        
        # Clean up temporary files
        for frame in frames:
            os.remove(frame)
        os.rmdir(temp_dir)
        
        return gif_path, total_reward, step, success
    else:
        # Just return the results without saving a GIF
        return None, total_reward, step, success

def create_comparison_gifs(grid_size, wall_density=0.1, fatal_density=0.05, slip_prob=0.2, 
                          reward_noise=0.1, uncertainty_param=0.1, n_episodes=1, seed=42, max_attempts=200):
    """
    Create GIFs comparing policy executions for different algorithms
    
    Args:
        grid_size: Size of the grid
        wall_density: Density of walls
        fatal_density: Density of fatal squares
        slip_prob: Probability of slipping
        reward_noise: Standard deviation of reward noise
        uncertainty_param: Uncertainty parameter
        n_episodes: Number of episodes to visualize
        seed: Random seed
        max_attempts: Maximum number of attempts to find successful episodes
    """
    print(f"Creating comparison GIFs for grid size {grid_size}...")
    
    # Create environment
    env = GridWorldV6(
        grid_size=grid_size,
        wall_density=wall_density,
        fatal_density=fatal_density,
        slip_prob=slip_prob,
        reward_noise=reward_noise,
        partial_observability=False,
        seed=seed
    )
    
    # Get optimal policy
    optimal_policy = env.get_optimal_policy()
    
    # Load trained algorithms
    models_dir = "models"
    algorithms = ['lcb_vi', 'chi_square_dro', 'bernstein_vi_lcb']
    policies = {'optimal': optimal_policy}
    
    for algo_name in algorithms:
        model_path = os.path.join(models_dir, f"{algo_name}_grid{grid_size}_param{uncertainty_param}.npz")
        
        if not os.path.exists(model_path):
            print(f"Model not found at {model_path}. Skipping.")
            continue
        
        # Initialize algorithm
        if algo_name == 'lcb_vi':
            algo = LCBVI(env.n_states, env.action_space.n, delta=uncertainty_param)
        elif algo_name == 'chi_square_dro':
            algo = ChiSquareDRO(env.n_states, env.action_space.n, kappa=uncertainty_param)
        elif algo_name == 'bernstein_vi_lcb':
            algo = BernsteinVILCB(env.n_states, env.action_space.n, grid_size=env.grid_size, alpha=uncertainty_param)
        
        # Load policy
        policy = algo.load(model_path)
        policies[algo_name] = policy
    
    # Create GIFs for each algorithm
    results = {algo: [] for algo in policies.keys()}
    successful_episodes = 0
    
    print("Finding maze layouts where ALL algorithms succeed...")
    attempts = 0
    max_attempts = 1000  # Try up to 1000 different maze layouts
    
    while successful_episodes < n_episodes and attempts < max_attempts:
        # Set seed for this attempt to generate a consistent maze
        episode_seed = (seed if seed is not None else 42) + attempts
        attempts += 1
        
        if attempts % 50 == 0:
            print(f"Attempt {attempts}...")
        
        # Create the SAME maze layout for all algorithms
        env = GridWorldV6(
            grid_size=grid_size,
            wall_density=wall_density,
            fatal_density=fatal_density,
            slip_prob=slip_prob,
            reward_noise=reward_noise,
            partial_observability=False,
            seed=episode_seed
        )
        
        # Check if ALL algorithms succeed on this maze
        all_success = True
        algorithm_results = {}
        
        for algo_name, policy in policies.items():
            # Reset the SAME environment (with the same maze layout)
            state, _ = env.reset()
            
            # Execute policy
            done = False
            episode_return = 0
            steps = 0
            max_steps = 200  # Max steps to prevent infinite loops
            frames = []
            
            while not done and steps < max_steps:
                # Get action from policy
                action = policy[state]
                
                # Render frame
                if steps % 2 == 0:  # Only capture every other frame to reduce GIF size
                    frame = env.render_array()
                    frames.append(frame)
                
                # Take action
                next_state, reward, done, _, _ = env.step(action)
                
                # Update state and return
                state = next_state
                episode_return += reward
                steps += 1
            
            # Check if this algorithm succeeded
            success = done and reward > 0  # Reached goal
            
            if not success:
                all_success = False  # This maze doesn't work for all algorithms
                break  # No need to check other algorithms
            
            # Store results for this algorithm
            algorithm_results[algo_name] = {
                'return': episode_return,
                'steps': steps,
                'frames': frames,
                'success': success
            }
        
        # If all algorithms succeeded, save the GIFs
        if all_success:
            print(f"\nFound maze layout where ALL algorithms succeed (attempt {attempts})")
            
            # Create GIFs for all algorithms with this maze
            for algo_name, result in algorithm_results.items():
                # We already verified success above, create GIF
                print(f"Creating policy execution GIF for {algo_name}...")
                
                # Reset environment with the same seed to ensure identical maze
                env = GridWorldV6(
                    grid_size=grid_size,
                    wall_density=wall_density,
                    fatal_density=fatal_density,
                    slip_prob=slip_prob,
                    reward_noise=reward_noise,
                    partial_observability=False,
                    seed=episode_seed
                )
            
                # Create GIF for this algorithm using its frames
                gif_path = f"data/visualizations/gifs/{algo_name}_grid{grid_size}_param{uncertainty_param}.gif"
                gif_v3 = f"data/gifs/{algo_name}_grid{grid_size}_param{uncertainty_param}.gif"
                
                # Save the frames as a GIF
                frames = result['frames']
                imageio.mimsave(gif_path, frames, fps=4)
                shutil.copy(gif_path, gif_v3)
                print(f"GIF saved to {gif_path}")
                print(f"GIF also saved to {gif_v3}")
                
                # Store results
                results[algo_name].append({
                    'episode': successful_episodes,
                    'total_reward': result['return'],
                    'steps': result['steps'],
                    'success': result['success'],
                    'gif_path': gif_path,
                    'seed': episode_seed
                })
            
            # Count this as a successful episode for all algorithms
            successful_episodes += 1
    
    # Report on successful episodes found
    print("\nSuccessful episodes found for each algorithm:")
    for algo_name in policies.keys():
        found = len([ep for ep in results[algo_name] if ep['success']])
        print(f"{ALGO_NAMES.get(algo_name, algo_name)}: {found}/{n_episodes}")
        
    
    # Save results
    results_path = f"data/visualizations/metrics/gif_comparison_grid{grid_size}_param{uncertainty_param}.pkl"
    with open(results_path, 'wb') as f:
        pickle.dump(results, f)
    shutil.copy(results_path, f"data/metrics/gif_comparison_grid{grid_size}_param{uncertainty_param}.pkl")
    
    # Create summary table
    summary = []
    for algo_name, episodes in results.items():
        if episodes:  # Only include algorithms with at least one successful episode
            avg_reward = np.mean([ep['total_reward'] for ep in episodes])
            success_rate = np.mean([1 if ep['success'] else 0 for ep in episodes])  # Should be 1.0 for all
            avg_steps = np.mean([ep['steps'] for ep in episodes])
            
            summary.append({
                'Algorithm': ALGO_NAMES[algo_name],
                'Average Reward': avg_reward,
                'Success Rate': success_rate,
                'Average Steps': avg_steps
            })
    
    df = pd.DataFrame(summary)
    print("\nGIF Comparison Summary (Successful Episodes Only):")
    print(df.to_string(index=False))
    
    # Save summary to CSV
    csv_path = f"data/visualizations/metrics/gif_comparison_grid{grid_size}_param{uncertainty_param}.csv"
    df.to_csv(csv_path, index=False)
    shutil.copy(csv_path, f"data/metrics/gif_comparison_grid{grid_size}_param{uncertainty_param}.csv")
    print(f"Summary saved to {csv_path}")

def plot_metrics_comparison(grid_sizes=[10, 20, 50], uncertainty_param=0.1):
    """
    Plot metrics comparing algorithms across different grid sizes
        grid_sizes: List of grid sizes to compare
        uncertainty_param: Uncertainty parameter
    """
    print(f"Plotting metrics comparison across grid sizes {grid_sizes}...")
    
    # Load results for each grid size
    results = {}
    for grid_size in grid_sizes:
        results_path = f"results/comparison_grid{grid_size}_param{uncertainty_param}.pkl"
        if os.path.exists(results_path):
            with open(results_path, 'rb') as f:
                results[grid_size] = pickle.load(f)
        else:
            print(f"Results not found for grid size {grid_size}. Skipping.")
    
    if not results:
        print("No results found. Exiting.")
        return
    
    # Prepare data for plotting
    data = []
    for grid_size, grid_results in results.items():
        for algo_name, metrics in grid_results.items():
            data.append({
                'Grid Size': grid_size,
                'Algorithm': algo_name,
                'Average Return': metrics['avg_return'],
                'Success Rate': metrics['success_rate'],
                'Average Steps': metrics['avg_steps']
            })
    
    df = pd.DataFrame(data)
    # Map algorithm keys to display names
    df['Algorithm'] = df['Algorithm'].map(ALGO_NAMES)
    
    # Plot average return
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Grid Size', y='Average Return', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Average Return vs Grid Size (Uncertainty = {uncertainty_param})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/avg_return_vs_grid_size_param{uncertainty_param}.png")
    plt.savefig(f"data/plots/avg_return_vs_grid_size_param{uncertainty_param}.png")
    plt.close()
    
    # Plot success rate
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Grid Size', y='Success Rate', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Success Rate vs Grid Size (Uncertainty = {uncertainty_param})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/success_rate_vs_grid_size_param{uncertainty_param}.png")
    plt.savefig(f"data/plots/success_rate_vs_grid_size_param{uncertainty_param}.png")
    plt.close()
    
    # Plot average steps
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Grid Size', y='Average Steps', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Average Steps vs Grid Size (Uncertainty = {uncertainty_param})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/avg_steps_vs_grid_size_param{uncertainty_param}.png")
    plt.savefig(f"data/plots/avg_steps_vs_grid_size_param{uncertainty_param}.png")
    plt.close()
    
    print("Plots saved to data/visualizations/plots/")

def plot_uncertainty_comparison(grid_size=10, uncertainty_param=0.1, uncertainty_params=[0.01, 0.05, 0.1, 0.2, 0.5]):
    """
    Plot metrics comparing algorithms across different uncertainty parameters
    
    Args:
        grid_size: Grid size to use
        uncertainty_param: Uncertainty parameter
        uncertainty_params: List of uncertainty parameters to compare
    """
    print(f"Plotting uncertainty comparison for grid size {grid_size}...")
    
    # Load results for each uncertainty parameter
    all_results = {}
    for param in uncertainty_params:
        results_path = f"results/comparison_grid{grid_size}_param{param}.pkl"
        
        if not os.path.exists(results_path):
            print(f"Results not found at {results_path}. Skipping.")
            continue
        
        with open(results_path, 'rb') as f:
            results = pickle.load(f)
            all_results[param] = results
    
    if not all_results:
        print("No results found for plotting.")
        return
    
    # Create dataframes for plotting
    plot_data = []
    for param, results in all_results.items():
        for algo_name, metrics in results.items():
            plot_data.append({
                'Uncertainty Parameter': param,
                'Algorithm': algo_name,
                'Average Return': metrics['avg_return'],
                'Success Rate': metrics['success_rate'],
                'Average Steps': metrics['avg_steps']
            })
    
    df = pd.DataFrame(plot_data)
    # Map algorithm keys to display names
    df['Algorithm'] = df['Algorithm'].map(ALGO_NAMES)
    
    # Plot average return
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Uncertainty Parameter', y='Average Return', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Average Return vs Uncertainty Parameter (Grid Size = {grid_size})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xscale('log')
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/avg_return_vs_uncertainty_grid{grid_size}.png")
    plt.savefig(f"data/plots/avg_return_vs_uncertainty_grid{grid_size}.png")
    plt.close()
    
    # Plot success rate
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Uncertainty Parameter', y='Success Rate', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Success Rate vs Uncertainty Parameter (Grid Size = {grid_size})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xscale('log')
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/success_rate_vs_uncertainty_grid{grid_size}.png")
    plt.savefig(f"data/plots/success_rate_vs_uncertainty_grid{grid_size}.png")
    plt.close()
    
    # Plot average steps
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Uncertainty Parameter', y='Average Steps', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Average Steps vs Uncertainty Parameter (Grid Size = {grid_size})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.xscale('log')
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/avg_steps_vs_uncertainty_grid{grid_size}.png")
    plt.savefig(f"data/plots/avg_steps_vs_uncertainty_grid{grid_size}.png")
    plt.close()
    
    print("Plots saved to data/visualizations/plots/")

def plot_slip_prob_comparison(grid_size=10, uncertainty_param=0.1, slip_probs=[0.0, 0.1, 0.2, 0.3, 0.5]):
    """
    Plot metrics comparing algorithms across different slip probabilities
    
    Args:
        grid_size: Grid size to use
        uncertainty_param: Uncertainty parameter to use
        slip_probs: List of slip probabilities to compare
    """
    print(f"Plotting slip probability comparison for grid size {grid_size}...")
    
    # Load results for each slip probability
    all_results = {}
    for slip_prob in slip_probs:
        results_path = f"results/slip_comparison_grid{grid_size}_param{uncertainty_param}_slip{slip_prob}.pkl"
        
        if not os.path.exists(results_path):
            print(f"Results not found at {results_path}. Skipping.")
            continue
        
        with open(results_path, 'rb') as f:
            results = pickle.load(f)
            all_results[slip_prob] = results
    
    if not all_results:
        print("No results found for plotting.")
        return
    
    # Create dataframes for plotting
    plot_data = []
    for slip_prob, results in all_results.items():
        for algo_name, metrics in results.items():
            plot_data.append({
                'Slip Probability': slip_prob,
                'Algorithm': algo_name,
                'Average Return': metrics['avg_return'],
                'Success Rate': metrics['success_rate'],
                'Average Steps': metrics['avg_steps']
            })
    
    df = pd.DataFrame(plot_data)
    df['Algorithm'] = df['Algorithm'].map(ALGO_NAMES)
    
    # Plot average return
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Slip Probability', y='Average Return', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Average Return vs Slip Probability (Grid Size = {grid_size}, Uncertainty = {uncertainty_param})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/avg_return_vs_slip_grid{grid_size}_param{uncertainty_param}.png")
    plt.savefig(f"data/plots/avg_return_vs_slip_grid{grid_size}_param{uncertainty_param}.png")
    plt.close()
    
    # Plot success rate
    plt.figure(figsize=(12, 8))
    sns.lineplot(x='Slip Probability', y='Success Rate', hue='Algorithm', 
                 data=df, palette=DISPLAY_COLORS, marker='o', markersize=8)
    plt.title(f'Success Rate vs Slip Probability (Grid Size = {grid_size}, Uncertainty = {uncertainty_param})')
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"data/visualizations/plots/success_rate_vs_slip_grid{grid_size}_param{uncertainty_param}.png")
    plt.savefig(f"data/plots/success_rate_vs_slip_grid{grid_size}_param{uncertainty_param}.png")
    plt.close()
    
    print("Plots saved to data/visualizations/plots/")

def plot_advanced_metrics(grid_size=15, uncertainty_param=0.1, n_trials=10, epsilon=0.1, discount_factor=0.99, sample_sizes=[50, 100, 200, 500]):
    """
    Calculate and plot advanced metrics for algorithm comparison:
    1. Suboptimality Gap (Δ_V)
    2. Empirical Sample-Efficiency Exponent (β)
    3. Success Rate with respect to suboptimality threshold
    4. Wall-Clock Time per Run
    5. Memory Footprint
    
    Args:
        grid_sizes: List of grid sizes to compare
        uncertainty_param: Uncertainty parameter
        n_trials: Number of trials for metric sampling per algorithm
        epsilon: Threshold for success rate calculation (Δ_V ≤ ε)
        sample_sizes: List of dataset sizes for fitting sample-efficiency exponent β
    """
    print(f"Calculating advanced metrics for grid size {grid_size}...")
    print(f"Parameters: uncertainty={uncertainty_param}, epsilon={epsilon}, discount_factor={discount_factor}")
    
    # Create directories for advanced metrics and logs
    os.makedirs("data/visualizations/advanced_metrics", exist_ok=True)
    os.makedirs("data/visualizations/advanced_metrics/logs", exist_ok=True)
    os.makedirs("data", exist_ok=True)
    os.makedirs("data/logs", exist_ok=True)
    
    # Create a log file with configuration details
    log_file = f"data/visualizations/advanced_metrics/logs/metrics_log_grid{grid_size}_param{uncertainty_param}.txt"
    with open(log_file, 'w') as f:
        f.write(f"Advanced Metrics Calculation Log\n")
        f.write(f"============================\n")
        f.write(f"Grid Size: {grid_size}x{grid_size}\n")
        f.write(f"Uncertainty Parameter: {uncertainty_param}\n")
        f.write(f"Suboptimality Threshold (epsilon): {epsilon}\n")
        f.write(f"Discount Factor: {discount_factor}\n")
        f.write(f"Number of Trials: {n_trials}\n")
        f.write(f"Date: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"============================\n\n")
    
    # Copy log file to datav3
    shutil.copy(log_file, f"data/logs/metrics_log_grid{grid_size}_param{uncertainty_param}.txt")
    
    # Initialize metrics storage
    all_metrics = {
        'suboptimality_gap': [],
        'sample_efficiency': [],
        'success_rate': [],
        'wall_clock_time': [],
        'memory_footprint': [],
        'success': [],
        'failed': [],
        'failed_to_finish': []
    }
    # Empirical sample-efficiency data storage
    sample_eff_data = {}
    
    print(f"Processing grid size {grid_size}...")
    
    # Create environment
    env = GridWorldV6(
        grid_size=grid_size,
        wall_density=0.15,
        fatal_density=0.08,
        slip_prob=0.1,
        reward_noise=0.1,
        partial_observability=False,
        seed=42
    )
        
    # Get optimal policy and its value function
    optimal_policy = env.get_optimal_policy()
    optimal_value = calculate_policy_value(env, optimal_policy)
    
    # Load trained algorithms
    algorithms = ['lcb_vi', 'chi_square_dro', 'bernstein_vi_lcb']
    policies = {}
        
    for algo_name in algorithms:
        fname = 'chi_square_dro' if algo_name == 'chi_square_dro' else algo_name
        model_path = f"models/{fname}_grid{grid_size}_param{uncertainty_param}.npz"
        
        if not os.path.exists(model_path):
            print(f"Model not found at {model_path}. Skipping.")
            continue
        
        # Initialize algorithm
        if algo_name == 'lcb_vi':
            algo = LCBVI(env.n_states, env.action_space.n, delta=uncertainty_param)
        elif algo_name == 'chi_square_dro':
            algo = ChiSquareDRO(env.n_states, env.action_space.n, kappa=uncertainty_param)
        elif algo_name == 'bernstein_vi_lcb':
            algo = BernsteinVILCB(env.n_states, env.action_space.n, grid_size=env.grid_size, alpha=uncertainty_param)
        
        # Load policy
        policy = algo.load(model_path)
        policies[algo_name] = policy
        
    # Calculate metrics for each algorithm
    for algo_name, policy in policies.items():
        print(f"Calculating metrics for {algo_name}...")
        
        # Run multiple trials
        subopt_gaps = []
        success_counts = 0
        times = []
        memory_usages = []
        sim_success_flags = []
        sim_fail_flags = []
        sim_unfinished_flags = []
        
        for trial in range(n_trials):
            # Simulate trajectory for success/failure
            traj = env.generate_trajectory(policy)
            sim_success_flags.append(traj['success'])
            done_flag = traj['dones'][-1] if traj['dones'] else False
            sim_fail_flags.append(done_flag and not traj['success'])
            sim_unfinished_flags.append(not done_flag)
            
            # Measure wall clock time
            start_time = time.time()
            
            # Calculate policy value
            policy_value = calculate_policy_value(env, policy)
            
            # Calculate suboptimality gap
            subopt_gap = optimal_value - policy_value
            subopt_gaps.append(subopt_gap)
            
            # Check if within epsilon threshold
            if subopt_gap <= epsilon:
                success_counts += 1
            
            # Record time
            times.append(time.time() - start_time)
            
            # Measure memory usage - use psutil for more reliable measurement
            import psutil
            process = psutil.Process(os.getpid())
            memory_usages.append(process.memory_info().rss / 1024 / 1024)  # Convert to MB
            
        # Calculate average suboptimality gap
        avg_subopt_gap = np.mean(subopt_gaps)
        
        # Calculate success rate
        success_rate = success_counts / n_trials
        
        # Calculate average time and memory
        avg_time = np.mean(times)
        avg_memory = np.mean(memory_usages)  # Already in MB
        
        # Calculate simulation-based rates
        sim_success_rate = sum(sim_success_flags) / n_trials
        failure_rate = sum(sim_fail_flags) / n_trials
        unfinished_rate = sum(sim_unfinished_flags) / n_trials
        
        # Empirical sample-efficiency exponent (β) via log–log regression
        deltas = []
        for N in sample_sizes:
            trajectories_N = generate_trajectories(env, n_expert=N, n_suboptimal=N, n_random=N)
            policy_N = train_algorithm(algo_name, env, trajectories_N, uncertainty_param=uncertainty_param)
            delta_N = optimal_value - calculate_policy_value(env, policy_N, discount_factor=discount_factor)
            deltas.append(delta_N)
        # Avoid log(0) issues
        deltas = [max(d, 1e-8) for d in deltas]
        logs_N = np.log(sample_sizes)
        logs_delta = np.log(deltas)
        slope, _ = np.polyfit(logs_N, logs_delta, 1)
        beta = -slope
        # Save raw ΔV vs N data
        pd.DataFrame({'SampleSize': sample_sizes, 'DeltaV': deltas}).to_csv(
            f"data/delta_vs_N_{algo_name}_grid{grid_size}_param{uncertainty_param}.csv", index=False
        )
        # Store sample-efficiency data for plotting
        sample_eff_data[algo_name] = {'sample_sizes': sample_sizes, 'deltas': deltas, 'beta': beta}
        
        # Clear memory between algorithm evaluations
        import gc
        gc.collect()  # Force garbage collection
        
        # Store metrics
        all_metrics['suboptimality_gap'].append({
            'Algorithm': algo_name,
            'Value': avg_subopt_gap
        })
        
        all_metrics['sample_efficiency'].append({
            'Algorithm': algo_name,
            'Value': beta
        })
        
        all_metrics['success_rate'].append({
            'Algorithm': algo_name,
            'Value': success_rate
        })
        
        all_metrics['wall_clock_time'].append({
            'Algorithm': algo_name,
            'Value': avg_time
        })
        
        all_metrics['memory_footprint'].append({
            'Algorithm': algo_name,
            'Value': avg_memory
        })
        
        all_metrics['success'].append({'Algorithm': algo_name, 'Value': sim_success_rate})
        all_metrics['failed'].append({'Algorithm': algo_name, 'Value': failure_rate})
        all_metrics['failed_to_finish'].append({'Algorithm': algo_name, 'Value': unfinished_rate})
        
        # Log detailed metrics for this algorithm
        with open(log_file, 'a') as f:
            f.write(f"Algorithm: {algo_name}\n")
            f.write(f"---------------------------\n")
            f.write(f"Suboptimality Gap (Δ_V): {avg_subopt_gap:.6f}\n")
            f.write(f"Sample Efficiency Exponent (β): {beta:.6f}\n")
            f.write(f"Success Rate (Δ_V ≤ {epsilon}): {success_rate:.6f}\n")
            f.write(f"Wall-Clock Time (seconds): {avg_time:.6f}\n")
            f.write(f"Memory Footprint (MB): {avg_memory:.2f}\n")
            f.write(f"Simulation Success Rate: {sim_success_rate:.6f}\n")
            f.write(f"Simulation Failure Rate: {failure_rate:.6f}\n")
            f.write(f"Simulation Unfinished Rate: {unfinished_rate:.6f}\n")
            f.write(f"---------------------------\n")
            
            # Log individual trial results for transparency
            f.write(f"Individual Trial Results:\n")
            for i, (gap, time_taken, memory) in enumerate(zip(subopt_gaps, times, memory_usages)):
                success = "Yes" if gap <= epsilon else "No"
                f.write(f"  Trial {i+1}: Gap={gap:.6f}, Success={success}, Time={time_taken:.6f}s, Memory={memory:.2f}MB\n")
            f.write("\n")
    
    # Create dataframes and plot metrics
    for metric_name, metric_data in all_metrics.items():
        df = pd.DataFrame(metric_data)
        
        # Save raw metric data to data
        df.to_csv(f"data/{metric_name}_grid{grid_size}_param{uncertainty_param}.csv", index=False)
        
        # Plot metric as bar chart
        plt.figure(figsize=(12, 8))
        sns.barplot(x='Algorithm', y='Value', hue='Algorithm', data=df, palette=ALGO_COLORS, legend=False)
        
        # Set title and labels
        if metric_name == 'suboptimality_gap':
            title = f'Suboptimality Gap (Δ_V) for Grid Size {grid_size} (ε = {epsilon})'
            ylabel = 'Δ_V = V*(ρ) - V^π(ρ)'
        elif metric_name == 'sample_efficiency':
            title = f'Empirical Sample-Efficiency Exponent (β) for Grid Size {grid_size}'
            ylabel = 'β (higher is better)'
        elif metric_name == 'success_rate':
            title = f'Success Rate (Δ_V ≤ {epsilon}) for Grid Size {grid_size}'
            ylabel = 'Success Rate'
        elif metric_name == 'wall_clock_time':
            title = f'Wall-Clock Time per Run for Grid Size {grid_size}'
            ylabel = 'Time (seconds)'
        elif metric_name == 'memory_footprint':
            title = f'Memory Footprint for Grid Size {grid_size}'
            ylabel = 'Memory Usage (MB)'
        elif metric_name == 'success':
            title = f'Simulation Success Rate for Grid Size {grid_size}'
            ylabel = 'Success Rate'
        elif metric_name == 'failed':
            title = f'Simulation Failure Rate for Grid Size {grid_size}'
            ylabel = 'Failure Rate'
        elif metric_name == 'failed_to_finish':
            title = f'Simulation Unfinished Rate for Grid Size {grid_size}'
            ylabel = 'Unfinished Rate'
        
        plt.title(title)
        plt.ylabel(ylabel)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.tight_layout()
        
        # Save plot
        plt.savefig(f"data/visualizations/advanced_metrics/{metric_name}_comparison_grid{grid_size}.png")
        plt.savefig(f"data/advanced_metrics/{metric_name}_comparison_grid{grid_size}.png")
        plt.close()
    
    # Plot ΔV vs N on log-log for each algorithm
    plt.figure(figsize=(8, 6))
    for algo, data in sample_eff_data.items():
        plt.plot(data['sample_sizes'], data['deltas'], marker='o', label=ALGO_NAMES.get(algo, algo), color=ALGO_COLORS.get(algo))
    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel('Sample Size (N)')
    plt.ylabel('ΔV (V* - V^π)')
    plt.title(f'Delta vs N Log-Log (Grid Size {grid_size})')
    plt.legend()
    plt.grid(True, which='both', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.savefig(f"data/visualizations/advanced_metrics/delta_vs_N_loglog_grid{grid_size}.png")
    plt.savefig(f"data/advanced_metrics/delta_vs_N_loglog_grid{grid_size}.png")
    plt.close()
    
    # Plot β comparison bar chart
    beta_df = pd.DataFrame([{'Algorithm': ALGO_NAMES.get(a, a), 'Beta': d['beta']} for a, d in sample_eff_data.items()])
    plt.figure(figsize=(8, 6))
    sns.barplot(x='Algorithm', y='Beta', data=beta_df, palette=list(ALGO_COLORS.values()))
    plt.title(f'Empirical Sample-Efficiency Exponent β (Grid Size {grid_size})')
    plt.ylabel('β')
    plt.tight_layout()
    plt.savefig(f"data/visualizations/advanced_metrics/beta_comparison_grid{grid_size}.png")
    plt.savefig(f"data/advanced_metrics/beta_comparison_grid{grid_size}.png")
    plt.close()
    # Save beta data
    beta_df.to_csv(f"data/beta_comparison_grid{grid_size}_param{uncertainty_param}.csv", index=False)
    
    print("Advanced metrics plots saved to data/visualizations/advanced_metrics/")

def calculate_policy_value(env, policy, discount_factor=0.99, n_episodes=20, max_steps=1000):
    """
    Estimate policy value via Monte Carlo rollouts.
    Args:
        env: GridWorld environment
        policy: Policy to evaluate
        discount_factor: Discount factor for future rewards
        n_episodes: Number of episodes to simulate
        max_steps: Max steps per episode
    Returns:
        Average discounted return over simulated episodes
    """
    returns = []
    for _ in range(n_episodes):
        traj = env.generate_trajectory(policy, max_steps=max_steps)
        G = 0.0
        for t, r in enumerate(traj['rewards']):
            G += (discount_factor ** t) * r
        returns.append(G)
    return np.mean(returns)

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Visualize GridWorldV6 results")
    
    # Visualization modes
    parser.add_argument("--gifs", action="store_true", help="Create policy execution GIFs")
    parser.add_argument("--metrics", action="store_true", help="Plot metrics comparison")
    parser.add_argument("--uncertainty", action="store_true", help="Plot uncertainty comparison")
    parser.add_argument("--slip", action="store_true", help="Plot slip probability comparison")
    parser.add_argument("--advanced-metrics", action="store_true", help="Calculate and plot advanced comparison metrics")
    
    # Parameters
    parser.add_argument("--grid-size", type=int, default=10, help="Grid size for GIFs")
    parser.add_argument("--uncertainty-param", type=float, default=0.1, help="Uncertainty parameter")
    parser.add_argument("--wall-density", type=float, default=0.1, help="Wall density")
    parser.add_argument("--fatal-density", type=float, default=0.05, help="Fatal square density")
    parser.add_argument("--slip-prob", type=float, default=0.2, help="Slip probability")
    parser.add_argument("--n-gif-episodes", type=int, default=5, help="Number of episodes for GIFs")
    parser.add_argument("--max-attempts", type=int, default=50, help="Maximum number of attempts to find successful episodes for GIFs")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    
    args = parser.parse_args()
    
    # Create GIFs
    if args.gifs:
        create_comparison_gifs(
            grid_size=args.grid_size,
            wall_density=args.wall_density,
            fatal_density=args.fatal_density,
            slip_prob=args.slip_prob,
            uncertainty_param=args.uncertainty_param,
            n_episodes=args.n_gif_episodes,
            seed=args.seed,
            max_attempts=args.max_attempts
        )
    
    # Plot metrics comparison
    if args.metrics:
        plot_metrics_comparison(
            grid_sizes=[8, 15],
            uncertainty_param=args.uncertainty_param
        )
    
    # Plot uncertainty comparison
    if args.uncertainty:
        plot_uncertainty_comparison(
            grid_size=args.grid_size,
            uncertainty_params=[0.01, 0.05, 0.1, 0.2, 0.5]
        )
    
    # Plot slip probability comparison
    if args.slip:
        plot_slip_prob_comparison(
            grid_size=args.grid_size,
            uncertainty_param=args.uncertainty_param,
            slip_probs=[0.0, 0.1, 0.2, 0.3, 0.5]
        )
        
    # Calculate and plot advanced metrics
    if args.advanced_metrics:
        plot_advanced_metrics(
            grid_size=15,
            uncertainty_param=args.uncertainty_param,
            n_trials=10,
            epsilon=0.1,
            discount_factor=0.99,  # Consistent with training
            sample_sizes=[50, 100, 200, 500]
        )
    
    # If no specific visualization mode is selected, run all
    if not (args.gifs or args.metrics or args.uncertainty or args.slip or args.advanced_metrics):
        print("Running all visualization modes...")
        
        create_comparison_gifs(
            grid_size=args.grid_size,
            wall_density=args.wall_density,
            fatal_density=args.fatal_density,
            slip_prob=args.slip_prob,
            uncertainty_param=args.uncertainty_param,
            n_episodes=args.n_gif_episodes,
            seed=args.seed,
            max_attempts=args.max_attempts
        )
        
        plot_metrics_comparison(
            grid_sizes=[8, 15],
            uncertainty_param=args.uncertainty_param
        )
        
        plot_uncertainty_comparison(
            grid_size=args.grid_size,
            uncertainty_params=[0.01, 0.05, 0.1, 0.2, 0.5]
        )
        
        plot_slip_prob_comparison(
            grid_size=args.grid_size,
            uncertainty_param=args.uncertainty_param,
            slip_probs=[0.0, 0.1, 0.2, 0.3, 0.5]
        )
        
        plot_advanced_metrics(
            grid_size=15,
            uncertainty_param=args.uncertainty_param,
            n_trials=10,
            epsilon=0.1,
            discount_factor=0.99,  # Consistent with training
            sample_sizes=[50, 100, 200, 500]
        )

if __name__ == "__main__":
    main()
