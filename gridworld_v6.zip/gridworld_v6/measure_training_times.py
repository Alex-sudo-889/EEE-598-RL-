import os
import time
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from env import GridWorldV6
from algos.lcb_vi import LCBVI
from algos.chi_square_dro import ChiSquareDRO
from algos.bernstein_vi_lcb import BernsteinVILCB
from algos.policy_generation import PolicyGenerator
import train


def measure_training_times(n_episodes=5000):
    """Measure actual training times for each algorithm with n_episodes."""
    print(f"Measuring training times with {n_episodes} episodes...")
    
    # Settings
    grid_size = 10
    wall_density = 0.1
    fatal_density = 0.05
    slip_prob = 0.2
    reward_noise = 0.1
    partial_obs = False
    seed = 42
    uncertainty_param = 0.1

    # Initialize environment
    env = GridWorldV6(
        grid_size=grid_size,
        wall_density=wall_density,
        fatal_density=fatal_density,
        slip_prob=slip_prob,
        reward_noise=reward_noise,
        partial_observability=partial_obs,
        seed=seed
    )

    # Generate training trajectories (optimal only)
    print(f"Generating {n_episodes} expert trajectories for training...")
    trajectories = train.generate_trajectories(
        env,
        n_expert=n_episodes,
        n_suboptimal=0,
        n_random=0,
        n_curriculum=0,
        n_simplified=0,
        optimality_min=1.0,
        optimality_max=1.0,
        force_generate=True
    )
    traj_dict = {'expert': trajectories}

    # Compute optimal baseline return
    print("Evaluating optimal policy...")
    pg = PolicyGenerator(env)
    optimal_policy = pg.generate_optimal_policy_astar()
    opt_metrics = train.evaluate_policy(env, optimal_policy, n_episodes=1000)
    optimal_return = opt_metrics['avg_return']

    results = []
    algos = ['lcb_vi', 'dro', 'bernstein_vi_lcb']
    display_names = {'lcb_vi': 'LCB-VI', 'dro': 'DRO', 'bernstein_vi_lcb': 'Bernstein-VI-LCB'}

    for key in algos:
        name = display_names[key]
        print(f"\nTraining {name}...")
        
        # Measure training time
        t0 = time.time()
        policy = train.train_algorithm(key, env, traj_dict, uncertainty_param=uncertainty_param, save_dir='models')
        train_time = time.time() - t0
        print(f"{name} training time: {train_time:.2f} seconds")

        # Evaluate policy
        print(f"Evaluating {name}...")
        m = train.evaluate_policy(env, policy, n_episodes=1000)
        success = m['success_rate']
        avg_return = m['avg_return']
        gap = optimal_return - avg_return

        results.append({
            'Algorithm': name,
            'Success Rate': success,
            'Training Time (s)': train_time,
            'Suboptimality Gap': gap
        })

    # Save results
    os.makedirs('datav5', exist_ok=True)
    df = pd.DataFrame(results)
    df.to_csv('datav5/measured_training_times.csv', index=False)
    print(f"Saved results to datav5/measured_training_times.csv")
    
    # Print results
    print("\nMeasured Training Times:")
    print(df[['Algorithm', 'Training Time (s)']])
    
    return df


if __name__ == '__main__':
    measure_training_times(5000)
