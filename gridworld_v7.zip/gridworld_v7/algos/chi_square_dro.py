import numpy as np
from scipy.optimize import minimize
from .base_algo import BaseAlgorithm

class ChiSquareDRO(BaseAlgorithm):
    """Chi-Square Distributionally Robust Optimization algorithm
    
    Implementation based on the paper:
    "Achieving the Time-Optimal Solution of Markov Decision Processes via
    Distributionally Robust Optimization" by Iyengar, 2005 and
    "Robust Reinforcement Learning Using Least Squares Policy Iteration with
    Provable Performance Guarantees" by Panaganti et al., 2020
    """
    
    def __init__(self, n_states, n_actions, kappa=1.0, gamma=0.99, epsilon=1e-6, max_iterations=1000, delta=0.05):
        """
        Initialize the Chi-Square DRO algorithm
        
        Args:
            n_states: Number of states in the environment
            n_actions: Number of actions in the environment
            kappa: Scaling factor for uncertainty set size (default=1.0 for theoretical guarantees)
            gamma: Discount factor
            epsilon: Convergence threshold
            max_iterations: Maximum number of iterations
            delta: Confidence parameter (1-delta is the confidence level)
        """
        super().__init__(n_states, n_actions, gamma)
        self.kappa = kappa  # Should be 1.0 for theoretical guarantees
        self.epsilon = epsilon
        self.max_iterations = max_iterations
        self.delta = delta
        
        # Initialize Q-values
        self.Q = None
        
        # Initialize empirical model parameters
        self.transition_counts = None  # N(s,a,s')
        self.reward_sums = None   # Sum of rewards for each (s,a)
        self.visit_counts = None  # N(s,a)
        self.empirical_rewards = None  # r_hat(s,a)
        self.empirical_transitions = None  # P_hat(s,a,s')
    
    def build_empirical_model(self, trajectories):
        """
        Build empirical transition and reward models from trajectories
        
        Args:
            trajectories: List of trajectories
        """
        print("Building empirical model from trajectories...")
        
        # Initialize counters
        self.transition_counts = np.zeros((self.n_states, self.n_actions, self.n_states))
        self.reward_sums = np.zeros((self.n_states, self.n_actions))
        self.visit_counts = np.zeros((self.n_states, self.n_actions))
        
        # Process trajectories
        for trajectory in trajectories:
            states = trajectory['states']
            actions = trajectory['actions']
            rewards = trajectory['rewards']
            next_states = trajectory['next_states']
            
            for t in range(len(actions)):
                s = states[t]
                a = actions[t]
                r = rewards[t]
                s_next = next_states[t]
                
                # Update counts
                self.transition_counts[s, a, s_next] += 1
                self.reward_sums[s, a] += r
                self.visit_counts[s, a] += 1
        
        # Compute empirical rewards
        self.empirical_rewards = np.zeros((self.n_states, self.n_actions))
        for s in range(self.n_states):
            for a in range(self.n_actions):
                if self.visit_counts[s, a] > 0:
                    self.empirical_rewards[s, a] = self.reward_sums[s, a] / self.visit_counts[s, a]
                else:
                    # For unvisited state-action pairs, set reward to 0
                    self.empirical_rewards[s, a] = 0.0
        
        # Compute empirical transition probabilities
        self.empirical_transitions = np.zeros((self.n_states, self.n_actions, self.n_states))
        for s in range(self.n_states):
            for a in range(self.n_actions):
                if self.visit_counts[s, a] > 0:
                    self.empirical_transitions[s, a] = self.transition_counts[s, a] / self.visit_counts[s, a]
                else:
                    # For unvisited state-action pairs, we'll handle this in the uncertainty set
                    # by setting it to the full simplex during robust Bellman backups
                    self.empirical_transitions[s, a] = np.ones(self.n_states) / self.n_states
        
        print("Model building complete.")
    
    def compute_uncertainty_radius(self, s, a):
        """
        Compute the radius of the chi-square uncertainty set for a state-action pair
        as per the paper: R_{s,a} = 48 * log_term / N(s,a)
        
        Args:
            s: State
            a: Action
            
        Returns:
            radius: The radius of the chi-square ball
        """
        # If we haven't visited this state-action pair, use a large radius
        if self.visit_counts[s, a] == 0:
            return float('inf')  # Effectively infinite radius
        
        # Compute the total number of samples
        N = np.sum(self.visit_counts)
        
        # Compute the log term from the paper
        log_term = np.log(4 * self.n_states * self.n_actions * N / ((1 - self.gamma) * self.delta))
        
        # Compute the radius using the formula from the paper (Eq. 9)
        # R_{s,a} = 48 * log_term / N(s,a)
        # Note: kappa should be 1.0 for theoretical guarantees
        radius = self.kappa * 48 * log_term / self.visit_counts[s, a]
        
        return radius
    
    def compute_support_function(self, s, a, V):
        """
        Compute the support function (minimum expected value) over the chi-square ball
        using the exact dual convex program as described in Iyengar's paper (2005):
        
        σ(V) = max_{0≤μ≤Span(V)} { hat_P(V-μ) - R_sa * Span(V-μ) }
        
        where Span(V) = max(V) - min(V)
        
        Args:
            s: State
            a: Action
            V: Current value function
            
        Returns:
            min_expected_value: Minimum expected value over the uncertainty set
        """
        # If we haven't visited this state-action pair, make it absorbing (self-loop)
        if self.visit_counts[s, a] == 0:
            return V[s]  # Absorbing state - can only transition to itself
        
        # Get nominal distribution and radius
        p_hat = self.empirical_transitions[s, a]
        radius = self.compute_uncertainty_radius(s, a)
        
        # Compute the span of V
        v_max = np.max(V)
        v_min = np.min(V)
        span_V = v_max - v_min
        
        # If span is very small, return nominal expected value
        if span_V < 1e-10:
            return np.dot(p_hat, V)
        
        # Sort values in ascending order for the closed-form solution
        sorted_indices = np.argsort(V)
        sorted_V = V[sorted_indices]
        sorted_p = p_hat[sorted_indices]
        
        # Implement Iyengar's O(S log S) algorithm for the dual problem
        # The optimal μ* is in [0, span_V]
        
        # First try μ = 0 (no shift)
        expected_value_0 = np.dot(p_hat, V)
        penalty_0 = radius * span_V
        result_0 = expected_value_0 - penalty_0
        
        # Then try μ = span_V (maximum shift)
        expected_value_span = np.dot(p_hat, V - span_V)
        penalty_span = 0  # Span(V - span_V) = 0
        result_span = expected_value_span - penalty_span
        
        # Choose the better of the two
        if result_0 >= result_span:
            return result_0
        
        # If neither boundary is optimal, find the optimal μ in (0, span_V)
        # This requires solving the dual problem
        
        # Compute the cumulative probabilities
        cum_prob = np.cumsum(sorted_p)
        
        # Find the optimal index i* where μ* is between V[i*] and V[i*+1]
        for i in range(len(sorted_V) - 1):
            # Compute the derivative of the objective at V[i]
            derivative = cum_prob[i] - radius
            
            # If derivative changes sign, we've found the optimal μ
            if derivative <= 0 and cum_prob[i+1] - radius > 0:
                # Linear interpolation to find μ*
                mu_star = sorted_V[i] + (sorted_V[i+1] - sorted_V[i]) * \
                          (radius - cum_prob[i]) / (cum_prob[i+1] - cum_prob[i])
                
                # Compute the result with μ*
                result = np.dot(p_hat, V - mu_star) - radius * (v_max - mu_star - v_min)
                return result
        
        # If we get here, one of the boundaries is optimal
        return max(result_0, result_span)
    
    def dro_value_iteration(self):
        """
        Run DRO Value Iteration with exact chi-square uncertainty sets
        as described in Algorithm 2 in the paper "Achieving the Asymptotically
        Minimax Optimal Sample Complexity of Offline RL - A DRO-Based Approach"
        
        Returns:
            policy: The learned policy
        """
        print("Running DRO Value Iteration...")
        
        # Compute total number of samples
        N = np.sum(self.visit_counts)
        
        # Set max iterations according to the paper: τ_max ≥ ln(N)/(1-γ)
        # This guarantees ||Q_τ - Q*||_∞ ≤ 1/N
        tau_max = int(np.ceil(np.log(N) / (1 - self.gamma)))
        iterations_to_use = min(tau_max, self.max_iterations)
        print(f"Using {iterations_to_use} iterations (paper recommends at least {tau_max})")
        
        # Initialize value function and policy
        V = np.zeros(self.n_states)
        Q = np.zeros((self.n_states, self.n_actions))
        self.policy = np.zeros(self.n_states, dtype=int)
        
        # Value iteration
        for iteration in range(iterations_to_use):
            V_prev = V.copy()
            
            # Update Q-values for each state-action pair
            for s in range(self.n_states):
                for a in range(self.n_actions):
                    # Compute robust expected value using support function
                    robust_expected_value = self.compute_support_function(s, a, V_prev)
                    
                    # Update Q-value with robust Bellman operator
                    Q[s, a] = self.empirical_rewards[s, a] + self.gamma * robust_expected_value
            
            # Update value function and policy
            for s in range(self.n_states):
                if np.any(self.visit_counts[s] > 0):  # Only update if we have data
                    # Get the best Q-value
                    V[s] = np.max(Q[s])
                    
                    # For policy, break ties among visited actions only
                    # This is important for the theoretical guarantees
                    visited_actions = np.where(self.visit_counts[s] > 0)[0]
                    if len(visited_actions) > 0:
                        # Among visited actions, choose the one with highest Q-value
                        self.policy[s] = visited_actions[np.argmax(Q[s, visited_actions])]
                    else:
                        # If no actions visited, use standard argmax
                        self.policy[s] = np.argmax(Q[s])
            
            # Check for convergence
            delta = np.max(np.abs(V - V_prev))
            if iteration % 10 == 0:
                print(f"  Iteration {iteration}, delta = {delta:.6f}")
            
            if delta < self.epsilon:
                print(f"Converged after {iteration+1} iterations.")
                break
        
        # Store the final value function and Q-values
        self.values = V.copy()
        self.Q = Q.copy()
        
        print("DRO value iteration complete.")
        return self.policy
    
    def train(self, trajectories):
        """
        Train the algorithm on trajectories
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            policy: The learned policy
        """
        # Build empirical model from trajectories
        self.build_empirical_model(trajectories)
        
        # Run DRO value iteration
        self.dro_value_iteration()
        
        return self.policy
    
    def save(self, filepath):
        """
        Save the algorithm to a file
        
        Args:
            filepath: Path to save the algorithm
        """
        np.savez(filepath, 
                 policy=self.policy, 
                 values=self.values if hasattr(self, 'values') else np.zeros(self.n_states),
                 Q=self.Q if hasattr(self, 'Q') else np.zeros((self.n_states, self.n_actions)),
                 n_states=self.n_states,
                 n_actions=self.n_actions,
                 gamma=self.gamma,
                 kappa=self.kappa,
                 empirical_rewards=self.empirical_rewards if hasattr(self, 'empirical_rewards') else None,
                 empirical_transitions=self.empirical_transitions if hasattr(self, 'empirical_transitions') else None,
                 visit_counts=self.visit_counts if hasattr(self, 'visit_counts') else None,
                 transition_counts=self.transition_counts if hasattr(self, 'transition_counts') else None,
                 reward_sums=self.reward_sums if hasattr(self, 'reward_sums') else None)
        print(f"Chi-Square DRO algorithm saved to {filepath}")
    
    def load(self, filepath):
        """
        Load the algorithm from a file
        
        Args:
            filepath: Path to load the algorithm from
            
        Returns:
            policy: The loaded policy
        """
        data = np.load(filepath, allow_pickle=True)
        self.policy = data['policy']
        
        # Load value function and Q-values if available
        if 'values' in data:
            self.values = data['values']
        if 'Q' in data:
            self.Q = data['Q']
            
        # Load algorithm parameters
        self.n_states = data['n_states']
        self.n_actions = data['n_actions']
        self.gamma = data['gamma']
        self.kappa = data['kappa']
        
        # Load model parameters if available
        if 'empirical_rewards' in data and data['empirical_rewards'] is not None:
            self.empirical_rewards = data['empirical_rewards']
        if 'empirical_transitions' in data and data['empirical_transitions'] is not None:
            self.empirical_transitions = data['empirical_transitions']
        if 'visit_counts' in data and data['visit_counts'] is not None:
            self.visit_counts = data['visit_counts']
        if 'transition_counts' in data and data['transition_counts'] is not None:
            self.transition_counts = data['transition_counts']
        if 'reward_sums' in data and data['reward_sums'] is not None:
            self.reward_sums = data['reward_sums']
            
        print(f"Chi-Square DRO algorithm loaded from {filepath}")
        
        return self.policy
