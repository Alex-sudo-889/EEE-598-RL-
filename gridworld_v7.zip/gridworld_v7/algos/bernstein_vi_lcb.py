import numpy as np
from .base_algo import BaseAlgorithm
import random
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier

class BernsteinVILCB(BaseAlgorithm):
    """Bernstein Value Iteration with Lower Confidence Bounds algorithm
    
    Implementation based on Algorithm 1 from:
    "Settling the Sample Complexity of Model-Based Reinforcement Learning with a Generative Model"
    by Zanette, Brunskill, et al.
    """
    
    def __init__(self, n_states, n_actions, grid_size=None, alpha=0.1, gamma=0.99, max_iterations=1000, epsilon=1e-6):
        """
        Initialize the Bernstein-VI-LCB algorithm
        
        Args:
            n_states: Number of states in the environment
            n_actions: Number of actions in the environment
            grid_size: Size of the grid (if None, inferred from n_states)
            alpha: Uncertainty parameter (related to delta in the paper)
            gamma: Discount factor
            max_iterations: Maximum number of value iteration steps
            epsilon: Convergence threshold for value iteration
        """
        super().__init__(n_states, n_actions, gamma)
        self.alpha = alpha
        self.max_iterations = max_iterations
        self.epsilon = epsilon
        
        # Infer grid size if not provided
        if grid_size is None:
            self.grid_size = int(np.sqrt(n_states))
        else:
            self.grid_size = grid_size
            
        # Initialize empirical model parameters
        self.visit_counts = None  # N(s,a)
        self.reward_sums = None   # Sum of rewards for each (s,a)
        self.transition_counts = None  # Count of transitions (s,a) -> s'
        self.empirical_rewards = None  # r_hat(s,a)
        self.empirical_transitions = None  # P_hat(s,a,s')
    
    def build_empirical_model(self, trajectories):
        """
        Build empirical transition and reward models from trajectories
        
        Args:
            trajectories: List of trajectories
        """
        print("Building empirical model from trajectories...")
        
        # Initialize counters
        self.transition_counts = np.zeros((self.n_states, self.n_actions, self.n_states))
        self.reward_sums = np.zeros((self.n_states, self.n_actions))
        self.visit_counts = np.zeros((self.n_states, self.n_actions))
        
        # Process trajectories
        for trajectory in trajectories:
            states = trajectory['states']
            actions = trajectory['actions']
            rewards = trajectory['rewards']
            next_states = trajectory['next_states']
            
            for t in range(len(actions)):
                s = states[t]
                a = actions[t]
                r = rewards[t]
                s_next = next_states[t]
                
                # Update counts
                self.transition_counts[s, a, s_next] += 1
                self.reward_sums[s, a] += r
                self.visit_counts[s, a] += 1
        
        # Compute empirical rewards
        self.empirical_rewards = np.zeros((self.n_states, self.n_actions))
        for s in range(self.n_states):
            for a in range(self.n_actions):
                if self.visit_counts[s, a] > 0:
                    self.empirical_rewards[s, a] = self.reward_sums[s, a] / self.visit_counts[s, a]
        
        # Compute empirical transition probabilities
        self.empirical_transitions = np.zeros((self.n_states, self.n_actions, self.n_states))
        for s in range(self.n_states):
            for a in range(self.n_actions):
                total = np.sum(self.transition_counts[s, a])
                if total > 0:
                    self.empirical_transitions[s, a] = self.transition_counts[s, a] / total
                else:
                    # If no data, use uniform distribution
                    self.empirical_transitions[s, a] = np.ones(self.n_states) / self.n_states
        
        print("Model building complete.")
    
    def compute_bernstein_bonus(self, s, a, V):
        """
        Compute the Bernstein penalty term for a state-action pair as per Eq (28) in
        "Settling the Sample Complexity of Model-Based Reinforcement Learning with a Generative Model"
        
        Args:
            s: State
            a: Action
            V: Current value function
            
        Returns:
            bonus: Bernstein penalty term
        """
        # If we haven't visited this state-action pair, use a large bonus
        if self.visit_counts[s, a] == 0:
            return 1.0 / (1.0 - self.gamma)  # Maximum possible value
        
        # Compute the variance of the next-state values
        next_state_values = np.zeros(self.n_states)
        for s_next in range(self.n_states):
            next_state_values[s_next] = self.empirical_transitions[s, a, s_next] * V[s_next]
            
        # Compute variance term: Var_{s'~P_hat[s,a]}[V(s')]
        expected_value = np.sum(next_state_values)
        variance = np.sum(self.empirical_transitions[s, a] * (V - expected_value)**2)
        
        # Total number of samples
        N = np.sum(self.visit_counts)  # Total number of samples
        
        # Compute log term as in the paper
        log_term = np.log(2 * self.n_states * self.n_actions * N / ((1 - self.gamma) * self.alpha))
        
        # Constant c_b from the paper (must be >= 144)
        c_b = 144.0
        
        # Compute the two terms in the max operation
        N_sa = self.visit_counts[s, a]
        # Fix: Put c_b inside the square root as per the paper's equation 28
        term1 = np.sqrt(c_b * variance * log_term / N_sa)
        term2 = 2 * c_b * log_term / ((1 - self.gamma) * N_sa)
        
        # Take max of the two terms
        max_term = max(term1, term2)
        
        # Clamp to maximum possible value
        clamped_term = min(max_term, 1.0 / (1.0 - self.gamma))
        
        # Add the slack term
        bonus = clamped_term + 5.0 / N
        
        return bonus
    
    def bernstein_vi(self):
        """
        Run Bernstein Value Iteration with Lower Confidence Bounds as per
        Algorithm 1 in "Settling the Sample Complexity of Model-Based 
        Reinforcement Learning with a Generative Model"
        
        Returns:
            policy: The learned policy
        """
        print("Running Value Iteration with Bernstein-LCB...")
        
        # Compute total number of samples
        N = np.sum(self.visit_counts)
        
        # Set max iterations according to the paper: τ_max ≥ ln(N)/(1-γ)
        # This guarantees ||Q_τ - Q*||_∞ ≤ 1/N
        tau_max = int(np.ceil(np.log(N) / (1 - self.gamma)))
        iterations_to_use = min(tau_max, self.max_iterations)
        print(f"Using {iterations_to_use} iterations (paper recommends at least {tau_max})")
        
        # Initialize value function and policy
        V = np.zeros(self.n_states)
        Q = np.zeros((self.n_states, self.n_actions))
        
        # Value iteration
        for iteration in range(iterations_to_use):
            V_prev = V.copy()
            
            # Update Q-values for each state-action pair
            for s in range(self.n_states):
                for a in range(self.n_actions):
                    # Compute expected next-state value
                    expected_value = 0
                    for s_next in range(self.n_states):
                        expected_value += self.empirical_transitions[s, a, s_next] * V_prev[s_next]
                    
                    # Compute bonus term
                    bonus = self.compute_bernstein_bonus(s, a, V_prev)
                    
                    # Update Q-value with pessimistic estimate
                    Q[s, a] = max(self.empirical_rewards[s, a] + self.gamma * expected_value - bonus, 0)
            
            # Update value function
            for s in range(self.n_states):
                if np.any(self.visit_counts[s] > 0):  # Only update if we have data
                    V[s] = np.max(Q[s])
            
            # Check for convergence
            delta = np.max(np.abs(V - V_prev))
            if iteration % 10 == 0:
                print(f"  Iteration {iteration}, delta = {delta:.6f}")
            
            if delta < self.epsilon:
                print(f"Converged after {iteration+1} iterations.")
                break
        
        # Store final value function and Q-values
        self.values = V.copy()
        self.Q = Q.copy()
        
        # Extract greedy policy
        self.policy = np.zeros(self.n_states, dtype=int)
        for s in range(self.n_states):
            if np.any(self.visit_counts[s] > 0):
                # Fix: Break ties only among visited actions as per Section 4.2
                visited = np.where(self.visit_counts[s] > 0)[0]
                if len(visited) > 0:
                    # Among visited actions, choose the one with highest Q-value
                    self.policy[s] = visited[np.argmax(Q[s, visited])]
                else:
                    # This should never happen if we checked visit_counts[s] > 0
                    self.policy[s] = np.argmax(Q[s])
        
        print("Bernstein-VI-LCB complete.")
        return self.policy
    
    def train(self, trajectories):
        """
        Train the algorithm on trajectories
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            policy: The learned policy
        """
        print("Processing trajectories with Bernstein-VI-LCB...")
        
        # Build empirical model from trajectories
        self.build_empirical_model(trajectories)
        
        # Run Bernstein Value Iteration
        self.bernstein_vi()
        
        return self.policy
        
    def save(self, filepath):
        """
        Save the algorithm to a file
        
        Args:
            filepath: Path to save the algorithm
        """
        np.savez(filepath, 
                 policy=self.policy,
                 values=self.values if hasattr(self, 'values') else np.zeros(self.n_states),
                 Q=self.Q if hasattr(self, 'Q') else np.zeros((self.n_states, self.n_actions)),
                 empirical_rewards=self.empirical_rewards,
                 empirical_transitions=self.empirical_transitions,
                 visit_counts=self.visit_counts,
                 n_states=self.n_states,
                 n_actions=self.n_actions,
                 gamma=self.gamma,
                 alpha=self.alpha)
        print(f"Bernstein-VI-LCB algorithm saved to {filepath}")
    
    def load(self, filepath):
        """
        Load the algorithm from a file
        
        Args:
            filepath: Path to load the algorithm from
            
        Returns:
            policy: The loaded policy
        """
        data = np.load(filepath)
        self.policy = data['policy']
        
        # Load value function and Q-values if available
        if 'values' in data:
            self.values = data['values']
        if 'Q' in data:
            self.Q = data['Q']
            
        # Load model parameters
        if 'empirical_rewards' in data:
            self.empirical_rewards = data['empirical_rewards']
        if 'empirical_transitions' in data:
            self.empirical_transitions = data['empirical_transitions']
        if 'visit_counts' in data:
            self.visit_counts = data['visit_counts']
            
        # Load algorithm parameters
        self.n_states = data['n_states']
        self.n_actions = data['n_actions']
        self.gamma = data['gamma']
        self.alpha = data['alpha']
        
        print(f"Bernstein-VI-LCB algorithm loaded from {filepath}")
        
        return self.policy

    def process_trajectories(self, trajectories):
        """
        Process trajectories for contextual bandit training
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            X: Feature matrix
            y: Action labels
            weights: Sample weights
        """
        X = []
        y = []
        weights = []
        
        # Track different trajectory types
        trajectory_counts = {
            'optimal': 0,
            'suboptimal': 0,
            'random': 0,
            'biased_random': 0,
            'curriculum': 0,
            'simplified': 0,
            'epsilon_greedy': 0,
            'unknown': 0
        }
        
        for trajectory in trajectories:
            states = trajectory['states']
            actions = trajectory['actions']
            policy_type = trajectory.get('policy_type', 'unknown')
            is_expert = trajectory.get('is_expert', False)
            
            # Count trajectory type
            if policy_type in trajectory_counts:
                trajectory_counts[policy_type] += 1
            else:
                trajectory_counts['unknown'] += 1
            
            # Assign weights based on trajectory type
            if policy_type == 'optimal' or policy_type == 'simplified':
                # Highest weight for optimal and simplified trajectories
                weight = 5.0
            elif policy_type == 'curriculum':
                # Higher weight for curriculum learning trajectories
                # Weight increases with difficulty level
                difficulty = trajectory.get('difficulty_level', 1)
                weight = 2.0 + difficulty
            elif policy_type == 'suboptimal':
                # Weight based on optimality
                optimality = trajectory.get('optimality', 0.7)
                weight = 1.0 + 3.0 * optimality  # Scale from 1.0 to 4.0
            elif policy_type == 'epsilon_greedy':
                # Medium weight for epsilon-greedy
                weight = 2.0
            else:  # random or biased_random
                # Lowest weight for random trajectories
                weight = 1.0
            
            # Add state-action pairs to dataset
            for s, a in zip(states[:-1], actions):
                X.append(self.extract_features(s))
                y.append(a)
                weights.append(weight)
        
        # Print summary of processed trajectories
        print(f"Processed trajectories by type:")
        for traj_type, count in trajectory_counts.items():
            if count > 0:
                print(f"  - {traj_type}: {count}")
        
        # Handle empty dataset case
        if len(X) == 0:
            print("Warning: No valid trajectories found. Creating dummy dataset.")
            # Create a dummy dataset with all actions represented
            for s in range(min(100, self.n_states)):  # Limit to 100 states to avoid excessive memory use
                for a in range(self.n_actions):
                    X.append(self.extract_features(s))
                    y.append(a)
                    weights.append(1.0)
        
        # Ensure we have at least one example of each action class
        action_counts = np.bincount(np.array(y), minlength=self.n_actions)
        for a in range(self.n_actions):
            if action_counts[a] == 0:
                print(f"Warning: No examples for action {a}. Adding dummy examples.")
                # Add dummy examples for this action
                for s in range(0, self.n_states, max(1, self.n_states // 10)):
                    X.append(self.extract_features(s))
                    y.append(a)
                    weights.append(0.5)  # Lower weight for dummy examples
        
        return np.vstack(X), np.array(y), np.array(weights)
    
    def extract_features(self, s):
        """
        Extract a one-hot feature vector for state index s for contextual bandit.
        """
        x = np.zeros(self.n_states)
        x[s] = 1.0
        return x
    
    def compute_lcb_policy(self):
        """
        Compute a policy with lower confidence bounds
        
        Returns:
            policy: The learned policy
        """
        print("Computing LCB policy...")
        
        # Initialize policy
        policy = np.zeros(self.n_states, dtype=int)
        
        # For each state, compute the LCB for each action and choose the best
        for s in range(self.n_states):
            features = self.extract_features(s)
            
            # If we have a trained model, use it
            if self.model is not None:
                try:
                    # Get action probabilities
                    action_probs = self.model.predict_proba(features.reshape(1, -1))[0]
                    
                    # Check if action_probs is empty or has NaN values
                    if len(action_probs) == 0 or np.any(np.isnan(action_probs)):
                        raise ValueError("Invalid action probabilities")
                    
                    # Compute LCB for each action
                    lcb = np.zeros(self.n_actions)
                    for a in range(self.n_actions):
                        p = action_probs[a]
                        # Compute Bernstein-style bonus with two-fold split
                        sa = self.n_states * self.n_actions
                        c = 2 * np.log(2 * sa / self.alpha)
                        # use evaluation sample count if available
                        n = max(1, getattr(self, 'n_eval_samples_', getattr(self.model, 'n_samples_', 1)))
                        var_hat = max(0, p * (1 - p))
                        bonus1 = np.sqrt(2 * var_hat * c / n)
                        bonus2 = 7 * c / (3 * n)
                        lcb[a] = p - bonus1 - bonus2
                    
                    # Choose action with highest LCB
                    if np.all(np.isnan(lcb)):
                        # If all LCBs are NaN, fall back to heuristic
                        raise ValueError("All LCBs are NaN")
                    
                    policy[s] = np.argmax(lcb)
                except (ValueError, IndexError) as e:
                    # Fall back to heuristic if there's any issue
                    print(f"Warning: Using heuristic policy for state {s} due to: {e}")
                    row, col = s // self.grid_size, s % self.grid_size
                    goal_row, goal_col = self.grid_size - 1, self.grid_size - 1
                    
                    # Simple heuristic: move towards the goal
                    if col < goal_col:
                        policy[s] = 2  # Right
                    else:
                        policy[s] = 1  # Down
            else:
                # If no model, use a simple heuristic
                row, col = s // self.grid_size, s % self.grid_size
                goal_row, goal_col = self.grid_size - 1, self.grid_size - 1
                
                # Simple heuristic: move towards the goal
                if col < goal_col:
                    policy[s] = 2  # Right
                else:
                    policy[s] = 1  # Down
        
        # Post-process the policy to ensure a path to the goal
        # This creates a simple policy: move right until the rightmost column, then move down
        for s in range(self.n_states):
            row, col = s // self.grid_size, s % self.grid_size
            goal_row, goal_col = self.grid_size - 1, self.grid_size - 1
            
            # If we're close to the goal, use a direct path
            if row >= self.grid_size - 3 and col >= self.grid_size - 3:
                if col < goal_col:
                    policy[s] = 2  # Right
                elif row < goal_row:
                    policy[s] = 1  # Down
        
        self.policy = policy
        return policy
    
    def train_lcb_contextual_bandit(self, X, y, weights):
        """
        Train a contextual bandit model with LCB
        
        Args:
            X: Feature matrix
            y: Action labels
            weights: Sample weights
        """
        print("Training LCB contextual bandit...")
        
        # If we have enough data, train a logistic regression model
        if len(X) > 10:
            # Use logistic regression with class weights
            self.model = LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=1000)
            
            # Create class weights from sample weights
            class_weights = {}
            for action in range(self.n_actions):
                action_indices = (y == action)
                if np.any(action_indices):
                    class_weights[action] = np.sum(weights[action_indices])
                else:
                    class_weights[action] = 1.0
            
            # Normalize class weights
            total_weight = sum(class_weights.values())
            for action in class_weights:
                class_weights[action] /= total_weight
                class_weights[action] *= len(y)  # Scale by number of samples
            
            # Train model
            self.model.class_weight = class_weights
            self.model.fit(X, y, sample_weight=weights)
            self.model.n_samples_ = len(X)
        else:
            # If not enough data, use a dummy classifier
            self.model = DummyClassifier(strategy='most_frequent')
            self.model.fit(X, y)
            self.model.n_samples_ = len(X)
        
        print("Contextual bandit training complete.")
    
    def train(self, trajectories):
        """
        Train the algorithm on trajectories
        
        Args:
            trajectories: List of trajectories
            
        Returns:
            policy: The learned policy
        """
        print("Processing trajectories with two-fold split...")
        # Two-fold data splitting
        data = trajectories.copy()
        random.shuffle(data)
        half = len(data) // 2
        D1, D2 = data[:half], data[half:]
        # Train model on first split
        X1, y1, w1 = self.process_trajectories(D1)
        self.train_lcb_contextual_bandit(X1, y1, w1)
        # Determine evaluation sample count from second split
        X2, y2, w2 = self.process_trajectories(D2)
        self.n_eval_samples_ = len(X2)
        # Compute policy
        return self.compute_lcb_policy()
    
    def save(self, filepath):
        """
        Save the algorithm to a file
        
        Args:
            filepath: Path to save the algorithm
        """
        # We can't directly save the sklearn model with np.savez
        # So we'll save the policy and other parameters
        np.savez(filepath, 
                 policy=self.policy, 
                 values=self.values,
                 n_states=self.n_states,
                 n_actions=self.n_actions,
                 gamma=self.gamma,
                 alpha=self.alpha,
                 grid_size=self.grid_size)
        print(f"Bernstein-VI-LCB algorithm saved to {filepath}")
    
    def load(self, filepath):
        """
        Load the algorithm from a file
        
        Args:
            filepath: Path to load the algorithm from
        """
        data = np.load(filepath)
        self.policy = data['policy']
        self.values = data['values']
        self.n_states = data['n_states']
        self.n_actions = data['n_actions']
        self.gamma = data['gamma']
        self.alpha = data['alpha']
        self.grid_size = data['grid_size']
        print(f"Bernstein-VI-LCB algorithm loaded from {filepath}")
        
        return self.policy
