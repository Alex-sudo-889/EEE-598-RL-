import os
import numpy as np
import pickle
import time
import argparse
import multiprocessing as mp
from tqdm import tqdm
from functools import partial

from env import GridWorldV6
from algos.lcb_vi import LCBVI
from algos.chi_square_dro import ChiSquareDRO
from algos.bernstein_vi_lcb import BernsteinVILCB
from algos.policy_generation import PolicyGenerator

def _generate_trajectory(env_params, policy_type, seed, optimality=None):
    """
    Generate a single trajectory using specified policy type (for parallel processing)
    
    Args:
        env_params: Dictionary of environment parameters
        policy_type: Type of policy to use ('optimal', 'suboptimal', 'epsilon_greedy', 'random', 'biased_random')
        seed: Random seed for reproducibility
        optimality: Optimality parameter for suboptimal policies (0.0 to 1.0)
        
    Returns:
        trajectory: The generated trajectory
    """
    # Set seed for reproducibility
    np.random.seed(seed)
    
    # Create environment
    env = GridWorldV6(**env_params)
    
    # Create policy generator
    policy_generator = PolicyGenerator(env)
    
    # Generate policy based on type
    if policy_type == 'optimal':
        policy = policy_generator.generate_optimal_policy_astar()
    elif policy_type == 'suboptimal':
        policy = policy_generator.generate_suboptimal_policy(optimality or 0.7)
    elif policy_type == 'epsilon_greedy':
        policy = policy_generator.generate_epsilon_greedy_policy(epsilon=0.2)
    elif policy_type == 'biased_random':
        policy = policy_generator.generate_biased_random_policy()
    else:  # random
        policy = policy_generator.generate_random_policy()
    
    # Generate trajectory
    trajectory = env.generate_trajectory(policy)
    
    # Add metadata
    trajectory['policy_type'] = policy_type
    if optimality is not None:
        trajectory['optimality'] = optimality
    
    # Mark as expert if optimal and successful
    if policy_type == 'optimal' and trajectory['success']:
        trajectory['is_expert'] = True
        return trajectory
    elif policy_type != 'optimal':
        trajectory['is_expert'] = False
        return trajectory
    
    return None  # Return None for failed optimal trajectories

def _generate_optimal_trajectory(env_params, seed):
    """
    Generate a single optimal trajectory using A* (for backward compatibility)
    
    Args:
        env_params: Dictionary of environment parameters
        seed: Random seed for reproducibility
        
    Returns:
        trajectory: The generated trajectory
    """
    return _generate_trajectory(env_params, 'optimal', seed)

def _generate_random_trajectory(env_params, seed):
    """
    Generate a single random trajectory (for backward compatibility)
    
    Args:
        env_params: Dictionary of environment parameters
        seed: Random seed for reproducibility
        
    Returns:
        trajectory: The generated trajectory
    """
    return _generate_trajectory(env_params, 'random', seed)

def generate_trajectories(env, n_expert=100, n_suboptimal=100, n_random=100, n_workers=None):
    """
    Generate a diverse set of trajectories using parallel processing
    
    Args:
        env: GridWorld environment
        n_expert: Number of expert trajectories to generate
        n_suboptimal: Number of sub-optimal trajectories to generate
        n_random: Number of random trajectories to generate
        n_workers: Number of parallel workers (defaults to CPU count)
        
    Returns:
        trajectories: Dictionary containing all trajectories
    """
    if n_workers is None:
        n_workers = min(32, mp.cpu_count())  # Use up to 32 workers
    
    print(f"Generating {n_expert} expert, {n_suboptimal} sub-optimal, and {n_random} random trajectories using {n_workers} workers...")
    
    # Prepare environment parameters for workers
    env_params = {
        'grid_size': env.grid_size,
        'wall_density': env.wall_density,
        'fatal_density': env.fatal_density,
        'slip_prob': env.slip_prob,
        'reward_noise': env.reward_noise,
        'partial_observability': env.partial_observability
    }
    
    # Generate optimal trajectories using A* in parallel
    expert_trajectories = []
    seeds = np.random.randint(0, 10000, size=n_expert * 2)  # Generate extra seeds in case some trajectories fail
    
    with mp.Pool(n_workers) as pool:
        worker_args = [(env_params, 'optimal', seed) for seed in seeds[:n_expert*2]]
        results = list(tqdm(pool.starmap(_generate_trajectory, worker_args), 
                           total=n_expert*2, desc="Optimal trajectories"))
    
    # Filter out None results (failed trajectories)
    expert_trajectories = [traj for traj in results if traj is not None]
    # Ensure we have exactly n_expert trajectories
    expert_trajectories = expert_trajectories[:n_expert]
    
    # Generate sub-optimal trajectories with varying optimality
    suboptimal_seeds = np.random.randint(20000, 30000, size=n_suboptimal)
    optimality_values = np.random.uniform(0.5, 0.9, size=n_suboptimal)
    
    with mp.Pool(n_workers) as pool:
        worker_args = [(env_params, 'suboptimal', seed, opt) 
                      for seed, opt in zip(suboptimal_seeds, optimality_values)]
        suboptimal_trajectories = list(tqdm(pool.starmap(_generate_trajectory, worker_args),
                                           total=n_suboptimal, desc="Sub-optimal trajectories"))
    
    # Generate random trajectories (mix of pure random and biased random)
    random_seeds = np.random.randint(30000, 40000, size=n_random)
    
    with mp.Pool(n_workers) as pool:
        # Mix of random and biased random policies
        worker_args = []
        for seed in random_seeds:
            # 70% pure random, 30% biased random
            policy_type = 'random' if np.random.random() < 0.7 else 'biased_random'
            worker_args.append((env_params, policy_type, seed))
        
        random_trajectories = list(tqdm(pool.starmap(_generate_trajectory, worker_args),
                                        total=n_random, desc="Random trajectories"))
    
    # Filter out None results
    suboptimal_trajectories = [traj for traj in suboptimal_trajectories if traj is not None]
    random_trajectories = [traj for traj in random_trajectories if traj is not None]
    
    print(f"Generated {len(expert_trajectories)} optimal, {len(suboptimal_trajectories)} sub-optimal, and {len(random_trajectories)} random trajectories")
    
    return {
        'expert': expert_trajectories,
        'suboptimal': suboptimal_trajectories,
        'random': random_trajectories
    }

def _train_algorithm_worker(args):
    """
    Worker function for training an algorithm in parallel
    
    Args:
        args: Tuple containing (algo_name, env_params, trajectories, uncertainty_param, save_dir, seed)
        
    Returns:
        Dictionary with training results
    """
    algo_name, env_params, trajectories, uncertainty_param, save_dir, seed = args
    
    # Set seed for reproducibility
    np.random.seed(seed)
    
    # Create environment
    env = GridWorldV6(**env_params)
    
    # Combine all trajectory types
    all_trajectories = []
    
    # Add expert trajectories (highest priority)
    if 'expert' in trajectories:
        all_trajectories.extend(trajectories['expert'])
    
    # Add sub-optimal trajectories (medium priority)
    if 'suboptimal' in trajectories:
        all_trajectories.extend(trajectories['suboptimal'])
    
    # Add random trajectories (lowest priority)
    if 'random' in trajectories:
        all_trajectories.extend(trajectories['random'])
    
    print(f"Training {algo_name} with uncertainty parameter {uncertainty_param}...")
    
    # Initialize algorithm
    if algo_name == 'lcb_vi':
        algo = LCBVI(env.n_states, env.action_space.n, delta=uncertainty_param)
    elif algo_name == 'chi_square_dro':
        algo = ChiSquareDRO(env.n_states, env.action_space.n, kappa=uncertainty_param)
    elif algo_name == 'bernstein_vi_lcb':
        algo = BernsteinVILCB(env.n_states, env.action_space.n, grid_size=env.grid_size, alpha=uncertainty_param)
    else:
        raise ValueError(f"Unknown algorithm: {algo_name}")
    
    # Train algorithm
    start_time = time.time()
    policy = algo.train(all_trajectories)
    train_time = time.time() - start_time
    
    print(f"{algo_name} training completed in {train_time:.2f} seconds")
    
    # Create save directory if it doesn't exist
    os.makedirs(save_dir, exist_ok=True)
    
    # Save algorithm
    save_path = os.path.join(save_dir, f"{algo_name}_grid{env.grid_size}_param{uncertainty_param}.npz")
    algo.save(save_path)
    
    # Evaluate policy
    metrics = evaluate_policy(env, policy, n_episodes=100)
    
    return {
        'algo_name': algo_name,
        'policy': policy,
        'metrics': metrics,
        'train_time': train_time
    }

def train_algorithms_parallel(algorithms, env, trajectories, uncertainty_param=0.1, save_dir='models', n_workers=None):
    """
    Train multiple algorithms in parallel
    
    Args:
        algorithms: List of algorithm names to train
        env: GridWorld environment
        trajectories: Dictionary containing expert and random trajectories
        uncertainty_param: Uncertainty parameter (alpha or kappa)
        save_dir: Directory to save the trained algorithms
        n_workers: Number of parallel workers (defaults to min(len(algorithms), CPU count))
        
    Returns:
        Dictionary of results for each algorithm
    """
    if n_workers is None:
        n_workers = min(len(algorithms), mp.cpu_count())
    
    print(f"Training {len(algorithms)} algorithms in parallel using {n_workers} workers...")
    
    # Prepare environment parameters for workers
    env_params = {
        'grid_size': env.grid_size,
        'wall_density': env.wall_density,
        'fatal_density': env.fatal_density,
        'slip_prob': env.slip_prob,
        'reward_noise': env.reward_noise,
        'partial_observability': env.partial_observability
    }
    
    # Prepare arguments for each worker
    worker_args = []
    for i, algo_name in enumerate(algorithms):
        seed = np.random.randint(0, 10000) + i  # Different seed for each algorithm
        worker_args.append((algo_name, env_params, trajectories, uncertainty_param, save_dir, seed))
    
    # Train algorithms in parallel
    results = {}
    with mp.Pool(n_workers) as pool:
        for result in pool.map(_train_algorithm_worker, worker_args):
            algo_name = result['algo_name']
            results[algo_name] = {
                'policy': result['policy'],
                'metrics': result['metrics'],
                'train_time': result['train_time']
            }
    
    return results

def train_algorithm(algo_name, env, trajectories, uncertainty_param=0.1, save_dir='models'):
    """
    Train a single algorithm on trajectories (non-parallel version)
    
    Args:
        algo_name: Name of the algorithm ('lcb_vi', 'chi_square_dro', or 'bernstein_vi_lcb')
        env: GridWorld environment
        trajectories: Dictionary containing various trajectory types
        uncertainty_param: Uncertainty parameter (alpha or kappa)
        save_dir: Directory to save the trained algorithm
        
    Returns:
        policy: The learned policy
    """
    print(f"Training {algo_name} with uncertainty parameter {uncertainty_param}...")
    # Support 'dro' alias for chi_square_dro
    real_name = 'chi_square_dro' if algo_name == 'dro' else algo_name
    
    # Prepare full trajectory list
    if isinstance(trajectories, list):
        all_trajectories = trajectories
    else:
        all_trajectories = []
        if 'expert' in trajectories:
            all_trajectories.extend(trajectories['expert'])
        if 'suboptimal' in trajectories:
            all_trajectories.extend(trajectories['suboptimal'])
        if 'curriculum' in trajectories:
            all_trajectories.extend(trajectories['curriculum'])
        if 'simplified' in trajectories:
            all_trajectories.extend(trajectories['simplified'])
        if 'epsilon_greedy' in trajectories:
            all_trajectories.extend(trajectories['epsilon_greedy'])
        # Add random trajectories (lowest priority)
        if 'random' in trajectories:
            all_trajectories.extend(trajectories['random'])
    
    # Initialize algorithm based on real name
    if real_name == 'lcb_vi':
        algo = LCBVI(env.n_states, env.action_space.n, delta=uncertainty_param)
    elif real_name == 'chi_square_dro':
        algo = ChiSquareDRO(env.n_states, env.action_space.n, kappa=uncertainty_param)
    elif real_name == 'bernstein_vi_lcb':
        algo = BernsteinVILCB(env.n_states, env.action_space.n, grid_size=env.grid_size, alpha=uncertainty_param)
    else:
        raise ValueError(f"Unknown algorithm: {algo_name}")
    
    # Train algorithm
    print(f"Training {real_name} with {len(all_trajectories)} trajectories...")
    policy = algo.train(all_trajectories)
    
    # Save model
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, f"{real_name}_grid{env.grid_size}_param{uncertainty_param}.npz")
    algo.save(save_path)
    print(f"Model saved to {save_path}")
    
    return policy

def train_until_success(algo_name, env, trajectories, target_success_rate=0.5, max_iterations=20, 
                       uncertainty_param=0.1, save_dir='models', n_eval_episodes=100, 
                       trajectory_augmentation_factor=1.5):
    """
    Train an algorithm until it achieves a target success rate or reaches maximum iterations
    
    Args:
        algo_name: Name of the algorithm
        env: GridWorld environment
        trajectories: List of trajectories
        target_success_rate: Target success rate to achieve (0.0 to 1.0)
        max_iterations: Maximum number of training iterations
        uncertainty_param: Uncertainty parameter (alpha or kappa)
        save_dir: Directory to save the model
        n_eval_episodes: Number of episodes for evaluation
        trajectory_augmentation_factor: Factor to increase trajectory count by each iteration
        
    Returns:
        policy: Trained policy
        metrics: Evaluation metrics
        iterations: Number of iterations performed
    """
    print(f"Training {algo_name} until success rate >= {target_success_rate} (max {max_iterations} iterations)")
    
    # Initialize algorithm
    if algo_name == 'lcb_vi':
        algo = LCBVI(env.n_states, env.action_space.n, delta=uncertainty_param)
    elif algo_name == 'chi_square_dro':
        algo = ChiSquareDRO(env.n_states, env.action_space.n, kappa=uncertainty_param)
    elif algo_name == 'bernstein_vi_lcb':
        algo = BernsteinVILCB(env.n_states, env.action_space.n, grid_size=env.grid_size, alpha=uncertainty_param)
    else:
        raise ValueError(f"Unknown algorithm: {algo_name}")
    
    current_trajectories = trajectories.copy()
    best_policy = None
    best_success_rate = 0.0
    best_metrics = None
    
    for iteration in range(1, max_iterations + 1):
        print(f"\n=== Iteration {iteration}/{max_iterations} ===")
        print(f"Training {algo_name} with {len(current_trajectories)} trajectories...")
        
        # Train algorithm
        policy = algo.train(current_trajectories)
        
        # Evaluate policy
        metrics = evaluate_policy(env, policy, n_episodes=n_eval_episodes)
        success_rate = metrics['success_rate']
        
        print(f"Success rate: {success_rate:.2f} (target: {target_success_rate:.2f})")
        print(f"Average return: {metrics['avg_return']:.2f}")
        print(f"Average steps: {metrics['avg_steps']:.2f}")
        
        # Save if this is the best policy so far
        if success_rate > best_success_rate:
            best_success_rate = success_rate
            best_policy = policy
            best_metrics = metrics
            
            # Save the best model so far
            save_path = os.path.join(save_dir, f"{algo_name}_grid{env.grid_size}_param{uncertainty_param}.npz")
            algo.save(save_path)
            print(f"New best model saved to {save_path}")
            
            # Also save with iteration number
            iter_save_path = os.path.join(save_dir, f"{algo_name}_grid{env.grid_size}_param{uncertainty_param}_iter{iteration}.npz")
            algo.save(iter_save_path)
        
        # Check if we've reached the target success rate
        if success_rate >= target_success_rate:
            print(f"Target success rate achieved after {iteration} iterations!")
            break
        
        # If not, augment the trajectories for the next iteration
        if iteration < max_iterations:
            # Generate more trajectories
            print(f"Augmenting trajectories for next iteration...")
            
            # Use the policy generator to create more trajectories
            policy_generator = PolicyGenerator(env)
            
            # Calculate how many of each type to generate
            n_optimal = int(len([t for t in trajectories if t.get('policy_type') == 'optimal']) * trajectory_augmentation_factor)
            n_suboptimal = int(len([t for t in trajectories if t.get('policy_type') == 'suboptimal']) * trajectory_augmentation_factor)
            n_random = int(len([t for t in trajectories if t.get('policy_type') == 'random']) * trajectory_augmentation_factor)
            n_curriculum = int(len([t for t in trajectories if t.get('policy_type') == 'curriculum']) * trajectory_augmentation_factor)
            n_simplified = int(len([t for t in trajectories if t.get('policy_type') == 'simplified']) * trajectory_augmentation_factor)
            
            # Generate additional trajectories
            additional_trajectories = policy_generator.generate_mixed_dataset(
                n_optimal=n_optimal,
                n_suboptimal=n_suboptimal,
                n_random=n_random,
                n_curriculum=n_curriculum,
                n_simplified=n_simplified,
                optimality_range=(0.5, 0.9)
            )
            
            # Filter out unsuccessful trajectories
            additional_trajectories = [t for t in additional_trajectories if t.get('success', False)]
            
            # Combine with original trajectories
            current_trajectories = trajectories + additional_trajectories
            print(f"Added {len(additional_trajectories)} trajectories, new total: {len(current_trajectories)}")
    
    # Return the best policy found
    if best_policy is None:
        print(f"Warning: No successful policy found after {max_iterations} iterations.")
        return policy, metrics, max_iterations
    else:
        return best_policy, best_metrics, iteration

def evaluate_policy(env, policy, n_episodes=100):
    """
    Evaluate a policy
    
    Args:
        env: GridWorld environment
        policy: Policy to evaluate
        n_episodes: Number of episodes to evaluate
        
    Returns:
        metrics: Dictionary containing evaluation metrics
    """
    print(f"Evaluating policy over {n_episodes} episodes...")
    
    total_returns = []
    success_count = 0
    step_counts = []
    
    for _ in tqdm(range(n_episodes), desc="Evaluation"):
        # Reset environment
        state, _ = env.reset()
        
        # Execute policy
        done = False
        episode_return = 0
        step_count = 0
        max_steps = 1000
        
        while not done and step_count < max_steps:
            action = policy[state]
            next_state, reward, done, _, _ = env.step(action)
            
            episode_return += reward
            state = next_state
            step_count += 1
            
            if done and reward > 0:  # Reached the goal
                success_count += 1
        
        total_returns.append(episode_return)
        step_counts.append(step_count)
    
    # Compute metrics
    avg_return = np.mean(total_returns)
    success_rate = success_count / n_episodes
    avg_steps = np.mean(step_counts)
    
    print(f"Average return: {avg_return:.2f}")
    print(f"Success rate: {success_rate:.2f}")
    print(f"Average steps: {avg_steps:.2f}")
    
    return {
        'avg_return': avg_return,
        'success_rate': success_rate,
        'avg_steps': avg_steps,
        'returns': total_returns,
        'step_counts': step_counts
    }

def generate_trajectories(env, n_expert=100, n_suboptimal=100, n_random=50, n_curriculum=50, n_simplified=50, optimality_min=0.5, optimality_max=0.9, force_generate=False):
    """
    Generate trajectories for training using enhanced policy generation methods
    
    Args:
        env: GridWorld environment
        n_expert: Number of expert trajectories using A*
        n_suboptimal: Number of sub-optimal trajectories
        n_random: Number of random trajectories (includes pure random and biased)
        n_curriculum: Number of curriculum learning trajectories
        n_simplified: Number of simplified environment demonstrations
        optimality_min: Minimum optimality for sub-optimal policies
        optimality_max: Maximum optimality for sub-optimal policies
        force_generate: Force generation of new trajectories
        
    Returns:
        trajectories: List of trajectories
    """
    # Define file path for trajectories
    trajectories_dir = os.path.join('data', 'trajectories')
    os.makedirs(trajectories_dir, exist_ok=True)
    trajectories_path = os.path.join(trajectories_dir, f'gridworld_{env.grid_size}x{env.grid_size}_enhanced_trajectories.pkl')
    
    # Check if trajectories already exist
    if os.path.exists(trajectories_path) and not force_generate:
        print(f"Loading trajectories from {trajectories_path}...")
        with open(trajectories_path, 'rb') as f:
            return pickle.load(f)
    
    print(f"Generating enhanced trajectories with A* and diverse policy types...")
    
    # Initialize policy generator
    policy_generator = PolicyGenerator(env)
    
    # Generate mixed dataset with enhanced methods
    trajectories = policy_generator.generate_mixed_dataset(
        n_optimal=n_expert,
        n_suboptimal=n_suboptimal,
        n_random=n_random,
        n_curriculum=n_curriculum,
        n_simplified=n_simplified,
        optimality_range=(optimality_min, optimality_max)
    )
    
    # Filter out unsuccessful trajectories
    successful_trajectories = [t for t in trajectories if t.get('success', False)]
    print(f"Filtered out {len(trajectories) - len(successful_trajectories)} unsuccessful trajectories")
    
    # Save trajectories
    with open(trajectories_path, 'wb') as f:
        pickle.dump(successful_trajectories, f)
    
    print(f"Generated {len(successful_trajectories)} successful trajectories and saved to {trajectories_path}")
    
    return successful_trajectories

def main(args):
    """
    Main function
    
    Args:
        args: Command-line arguments
    """
    # Create environment
    env = GridWorldV6(
        grid_size=args.grid_size,
        wall_density=args.wall_density,
        fatal_density=args.fatal_density,
        slip_prob=args.slip_prob,
        reward_noise=args.reward_noise,
        partial_observability=args.partial_observability,
        seed=args.seed
    )
    
    # Create data directory if it doesn't exist
    os.makedirs('data', exist_ok=True)
    os.makedirs('data/trajectories', exist_ok=True)
    
    # Generate or load trajectories
    trajectory_path = f"data/trajectories/gridworld_{args.grid_size}x{args.grid_size}_trajectories.pkl"
    if os.path.exists(trajectory_path) and not args.force_generate:
        print(f"Loading trajectories from {trajectory_path}...")
        with open(trajectory_path, 'rb') as f:
            trajectories = pickle.load(f)
    else:
        print(f"Generating new trajectories...")
        trajectories = generate_trajectories(
            env,
            n_expert=args.n_expert,
            n_suboptimal=args.n_suboptimal,
            n_random=args.n_random,
            n_curriculum=args.n_curriculum,
            n_simplified=args.n_simplified,
            optimality_min=args.optimality_min,
            optimality_max=args.optimality_max,
            force_generate=args.force_generate
        )
        
        # Save trajectories
        with open(trajectory_path, 'wb') as f:
            pickle.dump(trajectories, f)
        print(f"Trajectories saved to {trajectory_path}")
    
    # Train algorithms
    if args.algorithm == 'all':
        algorithms = ['lcb_vi', 'chi_square_dro', 'bernstein_vi_lcb']
    else:
        algorithms = [args.algorithm]
    
    # Determine whether to use parallel training
    if len(algorithms) > 1 and args.n_workers is not None:
        print(f"\n{'='*50}\nTraining algorithms in parallel\n{'='*50}")
        results = train_algorithms_parallel(
            algorithms,
            env,
            trajectories,
            uncertainty_param=args.uncertainty_param,
            save_dir=args.save_dir,
            n_workers=min(len(algorithms), args.n_workers)
        )
    else:
        # Sequential training for single algorithm or if parallel is disabled
        results = {}
        for algo_name in algorithms:
            print(f"\n{'='*50}\nTraining {algo_name}\n{'='*50}")
            policy = train_algorithm(
                algo_name, 
                env, 
                trajectories, 
                uncertainty_param=args.uncertainty_param,
                save_dir=args.save_dir
            )
            
            # Evaluate policy
            metrics = evaluate_policy(env, policy, n_episodes=args.n_eval_episodes)
            results[algo_name] = metrics
    
    # Save results
    results_path = os.path.join(
        args.save_dir, 
        f"results_grid{args.grid_size}_param{args.uncertainty_param}.pkl"
    )
    with open(results_path, 'wb') as f:
        pickle.dump(results, f)
    print(f"Results saved to {results_path}")

class TrainArgs:
    def __init__(
        self, grid_size=10, wall_density=0.2, fatal_density=0.1, slip_prob=0.2, reward_noise=0.1,
        partial_observability=False, algorithm='all', uncertainty_param=0.1, n_expert=100,
        n_suboptimal=100, n_random=50, n_curriculum=60, n_simplified=50, optimality_min=0.5, 
        optimality_max=0.9, n_eval_episodes=100, force_generate=False, n_workers=4, 
        save_dir='models', seed=None
    ):
        self.grid_size = grid_size
        self.wall_density = wall_density
        self.fatal_density = fatal_density
        self.slip_prob = slip_prob
        self.reward_noise = reward_noise
        self.partial_observability = partial_observability
        self.algorithm = algorithm
        self.uncertainty_param = uncertainty_param
        self.n_expert = n_expert
        self.n_suboptimal = n_suboptimal
        self.n_random = n_random
        self.n_curriculum = n_curriculum
        self.n_simplified = n_simplified
        self.optimality_min = optimality_min
        self.optimality_max = optimality_max
        self.n_eval_episodes = n_eval_episodes
        self.force_generate = force_generate
        self.n_workers = n_workers
        self.save_dir = save_dir
        self.seed = seed

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train algorithms on GridWorldV6")
    
    # Environment parameters
    parser.add_argument("--grid-size", type=int, default=10, help="Size of the grid")
    parser.add_argument("--wall-density", type=float, default=0.1, help="Density of walls")
    parser.add_argument("--fatal-density", type=float, default=0.05, help="Density of fatal squares")
    parser.add_argument("--slip-prob", type=float, default=0.2, help="Probability of slipping")
    parser.add_argument("--reward-noise", type=float, default=0.1, help="Standard deviation of reward noise")
    parser.add_argument("--partial-observability", action="store_true", help="Enable partial observability")
    
    # Training parameters
    parser.add_argument("--algorithm", type=str, default="all", choices=["lcb_vi", "chi_square_dro", "bernstein_vi_lcb", "dro", "all"], help="Algorithm to train")
    parser.add_argument("--uncertainty-param", type=float, default=0.1, help="Uncertainty parameter (alpha or kappa)")
    parser.add_argument("--n-expert", type=int, default=100, help="Number of expert trajectories")
    parser.add_argument("--n-suboptimal", type=int, default=100, help="Number of sub-optimal trajectories")
    parser.add_argument("--n-random", type=int, default=50, help="Number of random trajectories")
    parser.add_argument("--n-curriculum", type=int, default=60, help="Number of curriculum learning trajectories")
    parser.add_argument("--n-simplified", type=int, default=50, help="Number of simplified environment demonstrations")
    parser.add_argument("--optimality-min", type=float, default=0.5, help="Minimum optimality for sub-optimal policies")
    parser.add_argument("--optimality-max", type=float, default=0.9, help="Maximum optimality for sub-optimal policies")
    parser.add_argument("--n-eval-episodes", type=int, default=100, help="Number of evaluation episodes")
    parser.add_argument("--force-generate", action="store_true", help="Force generation of new trajectories")
    
    # Parallel processing parameters
    parser.add_argument("--n-workers", type=int, default=None, help="Number of parallel workers (default: use all available cores up to 32)")
    
    # Other parameters
    parser.add_argument("--save-dir", type=str, default="models", help="Directory to save models")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    
    args = parser.parse_args()
    main(args)
