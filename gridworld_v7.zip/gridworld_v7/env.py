import numpy as np
import gymnasium as gym
from gymnasium import spaces
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import random

class GridWorldV6(gym.Env):
    """Enhanced GridWorld Environment with customizable size, obstacles, and stochasticity"""
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 4}

    def __init__(self, 
                 grid_size=10, 
                 wall_density=0.1, 
                 fatal_density=0.05,
                 slip_prob=0.2, 
                 reward_noise=0.1,
                 partial_observability=False,
                 render_mode=None,
                 seed=None):
        """
        Initialize the GridWorld environment
        
        Args:
            grid_size: Size of the grid (grid_size x grid_size)
            wall_density: Percentage of grid cells that are walls (0.0 to 1.0)
            fatal_density: Percentage of grid cells that are fatal (red squares) (0.0 to 1.0)
            slip_prob: Probability of slipping (executing a random action instead of intended)
            reward_noise: Standard deviation of Gaussian noise added to rewards
            partial_observability: Whether to introduce partial observability
            render_mode: Rendering mode ('human', 'rgb_array', or None)
            seed: Random seed for reproducibility
        """
        super().__init__()
        
        # Set random seed if provided
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
        
        # Store parameters
        self.grid_size = grid_size
        self.wall_density = wall_density
        self.fatal_density = fatal_density
        self.slip_prob = slip_prob
        self.reward_noise = reward_noise
        # Reward scaling (normalize to [-1,1])
        self.goal_reward = 10.0
        self.reward_scale = 1.0 / self.goal_reward
        self.partial_observability = partial_observability
        self.render_mode = render_mode
        
        # Define action and observation spaces
        self.action_space = spaces.Discrete(4)  # 0: LEFT, 1: DOWN, 2: RIGHT, 3: UP
        self.observation_space = spaces.Discrete(grid_size * grid_size)
        
        # Grid dimensions
        self.nrow = grid_size
        self.ncol = grid_size
        self.n_states = grid_size * grid_size
        self.n_actions = 4
        
        # Generate grid
        self._generate_grid()
        
        # Initialize state
        self.state = self.start_pos
        self.lastaction = None
        
        # For rendering
        self.window = None
        self.clock = None
    
    def _generate_grid(self):
        """
        Generate a grid with start position, goal, walls, and fatal squares
        Ensures that there are multiple valid paths from start to goal
        """
        # Initialize grid with empty cells
        # 0: empty, 1: wall, 2: start, 3: goal, 4: fatal
        self.grid = np.zeros((self.nrow, self.ncol), dtype=int)
        
        # Place start position (top-left)
        self.start_pos = 0
        self.grid[0, 0] = 2
        
        # Place goal position (bottom-right)
        self.goal_pos = (self.nrow - 1) * self.ncol + (self.ncol - 1)
        self.grid[self.nrow - 1, self.ncol - 1] = 3
        
        # Place walls randomly based on density
        n_walls = int(self.wall_density * self.n_states)
        
        # Create a list of all possible positions for walls
        wall_candidates = [(r, c) for r in range(self.nrow) for c in range(self.ncol)
                          if (r != 0 or c != 0) and (r != self.nrow - 1 or c != self.ncol - 1)]
        
        # Shuffle the candidates
        random.shuffle(wall_candidates)
        
        # Place walls ensuring there's at least one valid path
        walls_placed = 0
        for r, c in wall_candidates:
            if walls_placed >= n_walls:
                break
                
            # Temporarily place a wall
            self.grid[r, c] = 1
            
            # Check if a path still exists from start to goal
            if self._check_path_exists():
                walls_placed += 1
            else:
                # Remove the wall if it blocks all paths
                self.grid[r, c] = 0
        
        # Place fatal squares (red) randomly based on density
        n_fatal = int(self.fatal_density * self.n_states)
        
        # Create a list of all possible positions for fatal squares
        fatal_candidates = [(r, c) for r in range(self.nrow) for c in range(self.ncol)
                           if self.grid[r, c] == 0]  # Only empty cells
        
        # Shuffle the candidates
        random.shuffle(fatal_candidates)
        
        # Place fatal squares ensuring there's at least one valid path
        fatal_placed = 0
        for r, c in fatal_candidates:
            if fatal_placed >= n_fatal:
                break
                
            # Temporarily place a fatal square
            self.grid[r, c] = 4
            
            # Check if a path still exists from start to goal
            if self._check_path_exists():
                fatal_placed += 1
            else:
                # Remove the fatal square if it blocks all paths
                self.grid[r, c] = 0
        
        # Create a human-readable description of the grid
        self.desc = np.array([['S' if cell == 2 else
                              'G' if cell == 3 else
                              'W' if cell == 1 else
                              'F' if cell == 4 else
                              ' ' for cell in row] for row in self.grid], dtype='c')
    
    def _check_path_exists(self):
        """
        Check if there's at least one valid path from start to goal using BFS
        """
        # Initialize visited array
        visited = np.zeros((self.nrow, self.ncol), dtype=bool)
        
        # Initialize queue with start position
        queue = [(0, 0)]  # Start position (top-left)
        visited[0, 0] = True
        
        # BFS
        while queue:
            r, c = queue.pop(0)
            
            # Check if we've reached the goal
            if r == self.nrow - 1 and c == self.ncol - 1:
                return True
            
            # Try all four directions
            for dr, dc in [(0, -1), (1, 0), (0, 1), (-1, 0)]:
                nr, nc = r + dr, c + dc
                
                # Check if the new position is valid
                if (0 <= nr < self.nrow and 0 <= nc < self.ncol and 
                    not visited[nr, nc] and self.grid[nr, nc] not in [1, 4]):  # Not a wall or fatal
                    queue.append((nr, nc))
                    visited[nr, nc] = True
        
        return False
    
    def reset(self, seed=None, options=None):
        """
        Reset the environment to the initial state
        """
        # Set random seed if provided
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
        
        # Reset state to start position
        self.state = self.start_pos
        self.lastaction = None
        
        # Return initial observation
        if self.partial_observability:
            # With partial observability, we might return a noisy observation
            if np.random.random() < 0.2:  # 20% chance of noisy initial observation
                # Find valid states (not walls or fatal)
                valid_states = [s for s in range(self.n_states) 
                               if self.grid[s // self.ncol, s % self.ncol] not in [1, 4]]
                if valid_states:
                    return np.random.choice(valid_states), {}
            
        return self.state, {}
    
    def step(self, action):
        """
        Take a step in the environment
        """
        # Apply stochasticity (slipperiness)
        if np.random.random() < self.slip_prob:
            # Execute a random action instead of the intended one
            action = np.random.choice([a for a in range(4) if a != action])
        
        # Get current position
        row = self.state // self.ncol
        col = self.state % self.ncol
        
        # Calculate goal position
        goal_row = (self.goal_pos // self.ncol)
        goal_col = (self.goal_pos % self.ncol)
        
        # Calculate current distance to goal (Manhattan distance)
        current_distance = abs(row - goal_row) + abs(col - goal_col)
        
        # Calculate new position based on action
        # 0: LEFT, 1: DOWN, 2: RIGHT, 3: UP
        newrow, newcol = row, col
        if action == 0:  # LEFT
            newcol = max(col - 1, 0)
        elif action == 1:  # DOWN
            newrow = min(row + 1, self.nrow - 1)
        elif action == 2:  # RIGHT
            newcol = min(col + 1, self.ncol - 1)
        elif action == 3:  # UP
            newrow = max(row - 1, 0)
        
        # Calculate new distance to goal
        new_distance = abs(newrow - goal_row) + abs(newcol - goal_col)
        
        # Default reward is negative (penalty for each step)
        reward = -0.1
        
        # Add distance-based reward component
        # Reward for moving closer to the goal, penalty for moving away
        if new_distance < current_distance:
            reward += 0.2  # Bonus for moving closer to goal
        elif new_distance > current_distance:
            reward -= 0.2  # Penalty for moving away from goal
        
        # Determine raw reward
        if self.grid[newrow, newcol] == 1:  # Wall
            newrow, newcol = row, col
            raw_reward = -0.5
        elif self.grid[newrow, newcol] == 4:  # Fatal
            raw_reward = -10.0
        elif self.grid[newrow, newcol] == 3:  # Goal
            raw_reward = self.goal_reward
        else:
            raw_reward = -0.1
        
        # Normalize and add noise
        reward = raw_reward * self.reward_scale
        reward += np.random.normal(0, self.reward_noise * self.reward_scale)
        
        # Check if we hit a fatal square
        done = False
        if self.grid[newrow, newcol] == 4:  # Fatal
            done = True
        
        # Check if we reached the goal
        if self.grid[newrow, newcol] == 3:  # Goal
            done = True
        
        # Update state
        self.state = newrow * self.ncol + newcol
        self.lastaction = action
        
        # Apply partial observability if enabled
        if self.partial_observability and not done:
            if np.random.random() < 0.2:  # 20% chance of noisy observation
                # Find valid states (not walls or fatal)
                valid_states = [s for s in range(self.n_states) 
                               if self.grid[s // self.ncol, s % self.ncol] not in [1, 4]]
                if valid_states:
                    observed_state = np.random.choice(valid_states)
                    return observed_state, reward, done, False, {}
        
        return self.state, reward, done, False, {}
    
    def render(self):
        """
        Render the environment
        """
        if self.render_mode is None:
            return
        
        # Create a colormap for visualization
        colors = ['white', 'black', 'green', 'blue', 'red']
        cmap = ListedColormap(colors)
        
        # Create a grid for visualization
        vis_grid = self.grid.copy()
        
        # Mark the current position
        current_row = self.state // self.ncol
        current_col = self.state % self.ncol
        if vis_grid[current_row, current_col] == 0:  # Only mark if it's an empty cell
            vis_grid[current_row, current_col] = 5  # New color for current position
        
        # Create a figure and axis
        fig, ax = plt.figure(figsize=(8, 8)), plt.gca()
        
        # Plot the grid
        ax.imshow(vis_grid, cmap=cmap, vmin=0, vmax=4)
        
        # Add grid lines
        ax.grid(which='major', axis='both', linestyle='-', color='k', linewidth=2)
        ax.set_xticks(np.arange(-0.5, self.ncol, 1))
        ax.set_yticks(np.arange(-0.5, self.nrow, 1))
        
        # Remove tick labels
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        
        # Add a title
        plt.title(f'GridWorldV6 ({self.nrow}x{self.ncol})')
        
        if self.render_mode == 'human':
            plt.show()
        elif self.render_mode == 'rgb_array':
            plt.close()
            return fig
    
    def get_optimal_policy(self):
        """
        Compute the optimal policy using value iteration
        """
        # Initialize value function
        V = np.zeros(self.n_states)
        policy = np.zeros(self.n_states, dtype=int)
        
        # Parameters for value iteration
        gamma = 0.99  # Discount factor
        theta = 1e-6  # Convergence threshold
        max_iterations = 1000
        
        # Value iteration
        for _ in range(max_iterations):
            delta = 0
            for s in range(self.n_states):
                row, col = s // self.ncol, s % self.ncol
                
                # Skip walls and fatal squares
                if self.grid[row, col] in [1, 4]:
                    continue
                
                # If goal state, value is fixed
                if self.grid[row, col] == 3:  # Goal
                    V[s] = 10.0
                    continue
                
                v = V[s]
                # Try all actions
                action_values = []
                for a in range(4):  # 0: LEFT, 1: DOWN, 2: RIGHT, 3: UP
                    # Calculate new position
                    newrow, newcol = row, col
                    if a == 0:  # LEFT
                        newcol = max(col - 1, 0)
                    elif a == 1:  # DOWN
                        newrow = min(row + 1, self.nrow - 1)
                    elif a == 2:  # RIGHT
                        newcol = min(col + 1, self.ncol - 1)
                    elif a == 3:  # UP
                        newrow = max(row - 1, 0)
                    
                    # Check if new position is valid
                    if self.grid[newrow, newcol] == 1:  # Wall
                        newrow, newcol = row, col
                        reward = -0.5 * self.reward_scale
                    elif self.grid[newrow, newcol] == 4:  # Fatal
                        reward = -10.0 * self.reward_scale
                    elif self.grid[newrow, newcol] == 3:  # Goal
                        reward = self.goal_reward * self.reward_scale
                    else:
                        reward = -0.1 * self.reward_scale
                    
                    # Calculate next state
                    next_state = newrow * self.ncol + newcol
                    
                    # Calculate expected value
                    action_value = reward + gamma * V[next_state]
                    action_values.append(action_value)
                
                # Update value function and policy
                best_action = np.argmax(action_values)
                best_value = action_values[best_action]
                
                V[s] = best_value
                policy[s] = best_action
                
                # Update delta
                delta = max(delta, abs(v - V[s]))
            
            # Check for convergence
            if delta < theta:
                break
        
        return policy
    
    def generate_trajectory(self, policy, max_steps=1000):
        """
        Generate a trajectory following the given policy
        """
        # Reset environment
        state, _ = self.reset()
        
        # Initialize trajectory
        states = [state]
        actions = []
        rewards = []
        next_states = []
        dones = []
        
        # Execute policy
        done = False
        step = 0
        
        while not done and step < max_steps:
            action = policy[state]
            next_state, reward, done, _, _ = self.step(action)
            
            actions.append(action)
            rewards.append(reward)
            next_states.append(next_state)
            dones.append(done)
            
            state = next_state
            states.append(state)
            step += 1
            
            if done:
                break
        
        return {
            'states': states[:-1],  # Remove the last state as it doesn't have a corresponding action
            'actions': actions,
            'rewards': rewards,
            'next_states': next_states,
            'dones': dones,
            'success': done and reward > 0,  # Success if reached goal
            'total_reward': sum(rewards)
        }
    
    def generate_expert_trajectories(self, n_trajectories=100):
        """
        Generate expert trajectories using the optimal policy
        """
        # Compute optimal policy
        optimal_policy = self.get_optimal_policy()
        
        # Generate trajectories
        trajectories = []
        for _ in range(n_trajectories):
            trajectory = self.generate_trajectory(optimal_policy)
            if trajectory['success']:
                trajectory['is_expert'] = True
                trajectories.append(trajectory)
        
        return trajectories
    
    def generate_random_trajectories(self, n_trajectories=1000):
        """
        Generate random trajectories
        """
        # Generate trajectories
        trajectories = []
        for _ in range(n_trajectories):
            # Create a random policy
            random_policy = np.random.randint(0, 4, size=self.n_states)
            
            trajectory = self.generate_trajectory(random_policy)
            trajectory['is_expert'] = False
            trajectories.append(trajectory)
        
        return trajectories
